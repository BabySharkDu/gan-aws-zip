-- ============================================================================
-- PostgreSQL Database Initialization for MediVault - PHP COMPATIBLE VERSION
-- Includes tables, functions, initial data, and sample records
-- This version works with PHP PDO (no psql-specific commands)
-- ============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- CREATE TABLES
-- ============================================================================

-- Roles table
CREATE TABLE IF NOT EXISTS roles (
    role_id SERIAL PRIMARY KEY,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Users table
CREATE TABLE IF NOT EXISTS users (
    user_id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role_id INTEGER REFERENCES roles(role_id),
    email VARCHAR(255) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    failed_login_attempts INTEGER DEFAULT 0,
    last_failed_login TIMESTAMP,
    last_login TIMESTAMP,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(user_id)
);

-- Patients table with encrypted fields
CREATE TABLE IF NOT EXISTS patients (
    patient_id SERIAL PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    ic_number_encrypted BYTEA NOT NULL,
    date_of_birth DATE NOT NULL,
    gender CHAR(1) CHECK (gender IN ('M', 'F', 'O')),
    phone_number_encrypted BYTEA NOT NULL,
    address TEXT,
    blood_type VARCHAR(5),
    emergency_contact VARCHAR(255),
    registered_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    registered_by INTEGER REFERENCES users(user_id)
);

-- Medical records table
CREATE TABLE IF NOT EXISTS medical_records (
    record_id SERIAL PRIMARY KEY,
    patient_id INTEGER REFERENCES patients(patient_id) ON DELETE CASCADE,
    doctor_id INTEGER REFERENCES users(user_id),
    visit_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    diagnosis TEXT NOT NULL,
    treatment TEXT NOT NULL,
    prescription TEXT,
    notes TEXT,
    bill_amount DECIMAL(10, 2) DEFAULT 0.00,
    status VARCHAR(20) DEFAULT 'Completed',
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Audit log table
CREATE TABLE IF NOT EXISTS audit_log (
    log_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(user_id),
    action VARCHAR(50) NOT NULL,
    table_affected VARCHAR(100),
    record_id INTEGER,
    ip_address VARCHAR(45),
    session_id VARCHAR(255),
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- CREATE INDEXES FOR PERFORMANCE
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role_id);
CREATE INDEX IF NOT EXISTS idx_patients_name ON patients(full_name);
CREATE INDEX IF NOT EXISTS idx_patients_dob ON patients(date_of_birth);
CREATE INDEX IF NOT EXISTS idx_medical_records_patient ON medical_records(patient_id);
CREATE INDEX IF NOT EXISTS idx_medical_records_doctor ON medical_records(doctor_id);
CREATE INDEX IF NOT EXISTS idx_medical_records_date ON medical_records(visit_date);
CREATE INDEX IF NOT EXISTS idx_audit_log_user ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_action ON audit_log(action);
CREATE INDEX IF NOT EXISTS idx_audit_log_timestamp ON audit_log(timestamp);

-- ============================================================================
-- HELPER FUNCTIONS
-- ============================================================================

-- Function to log audit events
CREATE OR REPLACE FUNCTION log_audit(
    p_user_id INTEGER,
    p_action VARCHAR,
    p_table_affected VARCHAR,
    p_record_id INTEGER DEFAULT NULL,
    p_details TEXT DEFAULT NULL
) RETURNS VOID AS $$
BEGIN
    INSERT INTO audit_log (user_id, action, table_affected, record_id, details)
    VALUES (p_user_id, p_action, p_table_affected, p_record_id, p_details);
END;
$$ LANGUAGE plpgsql;

-- Function to encrypt sensitive data
CREATE OR REPLACE FUNCTION encrypt_data(plain_text TEXT, encryption_key TEXT) 
RETURNS BYTEA AS $$
BEGIN
    RETURN pgp_sym_encrypt(plain_text, encryption_key);
END;
$$ LANGUAGE plpgsql;

-- Function to decrypt sensitive data
CREATE OR REPLACE FUNCTION decrypt_data(encrypted_data BYTEA, encryption_key TEXT) 
RETURNS TEXT AS $$
BEGIN
    RETURN pgp_sym_decrypt(encrypted_data, encryption_key);
EXCEPTION
    WHEN OTHERS THEN
        RETURN '[DECRYPTION ERROR]';
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- INSERT INITIAL DATA
-- ============================================================================

-- Insert roles
INSERT INTO roles (role_name, description) VALUES
    ('Administrator', 'Full system access - user management and system configuration'),
    ('Doctor', 'Medical staff - full patient record access'),
    ('Receptionist', 'Front desk - patient registration and basic info'),
    ('Auditor', 'Security auditor - read-only audit log access')
ON CONFLICT (role_name) DO NOTHING;

-- Insert default users with hashed passwords
-- Password: Admin@MediVault2025!
INSERT INTO users (username, password_hash, role_id, email, created_by) VALUES
    ('mvadmin', 
     '$argon2id$v=19$m=65536,t=4,p=1$dFJiNHZvN3ZRbVpUUFU4YQ$jS6TJmjHje7egdE8QlNetnTXB7LijyL76eTZ3T8Mw78', 
     1, 
     'admin@medivault.local',
     NULL)
ON CONFLICT (username) DO NOTHING;

-- Password: DoctorWong@MediVault2025!
INSERT INTO users (username, password_hash, role_id, email, created_by) VALUES
    ('dr.wong', 
     '$argon2id$v=19$m=65536,t=4,p=1$aWVlVG5vM1JZZExvRS5meA$HWDIb7UqrbQQRYj6RSEUsi+oWriRlystk1Y7t3qQ5wg', 
     2, 
     'dr.wong@medivault.local',
     1)
ON CONFLICT (username) DO NOTHING;

-- Password: DoctorGan@MediVault2025!
INSERT INTO users (username, password_hash, role_id, email, created_by) VALUES
    ('dr.gan', 
     '$argon2id$v=19$m=65536,t=4,p=1$VnZNUW1lRUQzRWZQOHBZOQ$SnqTzUxc2zy6a2MV7zzSZRbri0/+JIBK8ByX5TezJ+s', 
     2, 
     'dr.gan@medivault.local',
     1)
ON CONFLICT (username) DO NOTHING;

-- Password: Reception@MediVault2025!
INSERT INTO users (username, password_hash, role_id, email, created_by) VALUES
    ('reception', 
     '$argon2id$v=19$m=65536,t=4,p=1$cUpGT05kMDY0TEo5cm1CeA$h97e6/Xk/vIrXnGPTDFOd1it12+WqF2CgA6Wh1AZzSg', 
     3, 
     'reception@medivault.local',
     1)
ON CONFLICT (username) DO NOTHING;

-- Password: Auditor@MediVault2025!
INSERT INTO users (username, password_hash, role_id, email, created_by) VALUES
    ('auditor1', 
     '$argon2id$v=19$m=65536,t=4,p=1$YlI2bnQxUGo4Qi82YThoVA$9/gOEeYedtCkjWoJ7h/n3PBP0Nm7fnQQ0V5OGKKPxo0', 
     4, 
     'auditor1@medivault.local',
     1)
ON CONFLICT (username) DO NOTHING;

-- ============================================================================
-- INSERT SAMPLE PATIENTS
-- ============================================================================

-- Patient 1: Ahmad bin Abdullah
INSERT INTO patients (full_name, ic_number_encrypted, date_of_birth, gender, phone_number_encrypted, address, blood_type, emergency_contact, registered_by)
SELECT 
    'Ahmad bin Abdullah',
    pgp_sym_encrypt('850215-10-1234', 'n9Xp2vL5mK8jR4qW7zY3bC6dF0gH1tJ5'),
    '1985-02-15',
    'M',
    pgp_sym_encrypt('012-3456789', 'n9Xp2vL5mK8jR4qW7zY3bC6dF0gH1tJ5'),
    'No. 123, Jalan Bunga Raya, 50100 Kuala Lumpur',
    'O+',
    'Fatimah (Wife) - 012-9876543',
    4
WHERE NOT EXISTS (
    SELECT 1 FROM patients WHERE full_name = 'Ahmad bin Abdullah'
);

-- Patient 2: Tan Mei Ling
INSERT INTO patients (full_name, ic_number_encrypted, date_of_birth, gender, phone_number_encrypted, address, blood_type, emergency_contact, registered_by)
SELECT
    'Tan Mei Ling',
    pgp_sym_encrypt('920801-14-5678', 'n9Xp2vL5mK8jR4qW7zY3bC6dF0gH1tJ5'),
    '1992-08-01',
    'F',
    pgp_sym_encrypt('016-7654321', 'n9Xp2vL5mK8jR4qW7zY3bC6dF0gH1tJ5'),
    'Unit 5-2, Menara Vista, Jalan Ampang, 50450 Kuala Lumpur',
    'A+',
    'Tan Ah Kow (Father) - 016-1234567',
    4
WHERE NOT EXISTS (
    SELECT 1 FROM patients WHERE full_name = 'Tan Mei Ling'
);

-- Patient 3: Raj Kumar a/l Subramaniam
INSERT INTO patients (full_name, ic_number_encrypted, date_of_birth, gender, phone_number_encrypted, address, blood_type, emergency_contact, registered_by)
SELECT
    'Raj Kumar a/l Subramaniam',
    pgp_sym_encrypt('780910-05-3456', 'n9Xp2vL5mK8jR4qW7zY3bC6dF0gH1tJ5'),
    '1978-09-10',
    'M',
    pgp_sym_encrypt('011-2345678', 'n9Xp2vL5mK8jR4qW7zY3bC6dF0gH1tJ5'),
    '456 Jalan Gasing, 46000 Petaling Jaya, Selangor',
    'B+',
    'Devi (Wife) - 011-8765432',
    4
WHERE NOT EXISTS (
    SELECT 1 FROM patients WHERE full_name = 'Raj Kumar a/l Subramaniam'
);

-- Patient 4: Siti Nurhaliza binti Hassan
INSERT INTO patients (full_name, ic_number_encrypted, date_of_birth, gender, phone_number_encrypted, address, blood_type, emergency_contact, registered_by)
SELECT
    'Siti Nurhaliza binti Hassan',
    pgp_sym_encrypt('880520-08-7890', 'n9Xp2vL5mK8jR4qW7zY3bC6dF0gH1tJ5'),
    '1988-05-20',
    'F',
    pgp_sym_encrypt('019-8765432', 'n9Xp2vL5mK8jR4qW7zY3bC6dF0gH1tJ5'),
    '789 Jalan Sultan, 75000 Melaka',
    'AB+',
    'Hassan (Father) - 019-1234567',
    4
WHERE NOT EXISTS (
    SELECT 1 FROM patients WHERE full_name = 'Siti Nurhaliza binti Hassan'
);

-- Patient 5: Lim Chong Wei
INSERT INTO patients (full_name, ic_number_encrypted, date_of_birth, gender, phone_number_encrypted, address, blood_type, emergency_contact, registered_by)
SELECT
    'Lim Chong Wei',
    pgp_sym_encrypt('750315-12-2345', 'n9Xp2vL5mK8jR4qW7zY3bC6dF0gH1tJ5'),
    '1975-03-15',
    'M',
    pgp_sym_encrypt('017-6543210', 'n9Xp2vL5mK8jR4qW7zY3bC6dF0gH1tJ5'),
    '321 Jalan Putra, 11600 Penang',
    'A-',
    'Wong Mei Ling (Wife) - 017-1234098',
    4
WHERE NOT EXISTS (
    SELECT 1 FROM patients WHERE full_name = 'Lim Chong Wei'
);

-- ============================================================================
-- INSERT SAMPLE MEDICAL RECORDS
-- ============================================================================

-- Medical Record 1 - Ahmad bin Abdullah (by Dr. Wong)
INSERT INTO medical_records (patient_id, doctor_id, diagnosis, treatment, prescription, notes, bill_amount, status)
SELECT 1, 2,
    'Acute Upper Respiratory Tract Infection',
    'Rest, increased fluid intake, symptomatic treatment',
    'Paracetamol 500mg (2 tablets every 6 hours as needed), Loratadine 10mg (1 tablet daily)',
    'Patient presented with fever, cough, and sore throat for 3 days. No difficulty breathing. Advised to return if symptoms worsen.',
    85.00,
    'Completed'
WHERE NOT EXISTS (
    SELECT 1 FROM medical_records WHERE patient_id = 1 AND doctor_id = 2 AND diagnosis LIKE 'Acute Upper%'
);

-- Medical Record 2 - Tan Mei Ling (by Dr. Wong)
INSERT INTO medical_records (patient_id, doctor_id, diagnosis, treatment, prescription, notes, bill_amount, status)
SELECT 2, 2,
    'Hypertension - Follow-up',
    'Continue current medication, dietary modifications',
    'Amlodipine 5mg (1 tablet daily), Atorvastatin 20mg (1 tablet at night)',
    'Blood pressure: 135/85 mmHg. Patient compliant with medication. Advised low-salt diet and regular exercise.',
    120.00,
    'Completed'
WHERE NOT EXISTS (
    SELECT 1 FROM medical_records WHERE patient_id = 2 AND diagnosis LIKE 'Hypertension%'
);

-- Medical Record 3 - Raj Kumar (by Dr. Gan)
INSERT INTO medical_records (patient_id, doctor_id, diagnosis, treatment, prescription, notes, bill_amount, status)
SELECT 3, 3,
    'Type 2 Diabetes Mellitus - New Diagnosis',
    'Lifestyle modification, initiate oral hypoglycemic agent',
    'Metformin 500mg (1 tablet twice daily with meals)',
    'HbA1c: 7.8%. Patient counseled on diabetic diet and exercise. Follow-up in 3 months.',
    150.00,
    'Completed'
WHERE NOT EXISTS (
    SELECT 1 FROM medical_records WHERE patient_id = 3 AND diagnosis LIKE 'Type 2 Diabetes%'
);

-- Medical Record 4 - Siti Nurhaliza (by Dr. Wong)
INSERT INTO medical_records (patient_id, doctor_id, diagnosis, treatment, prescription, notes, bill_amount, status)
SELECT 4, 2,
    'Migraine',
    'Avoid triggers, regular sleep schedule',
    'Sumatriptan 50mg (as needed for migraine attacks, max 2 tablets per day)',
    'Headache diary recommended. Avoid caffeine and chocolate. Return if frequency increases.',
    95.00,
    'Completed'
WHERE NOT EXISTS (
    SELECT 1 FROM medical_records WHERE patient_id = 4 AND diagnosis = 'Migraine'
);

-- Medical Record 5 - Lim Chong Wei (by Dr. Gan)
INSERT INTO medical_records (patient_id, doctor_id, diagnosis, treatment, prescription, notes, bill_amount, status)
SELECT 5, 3,
    'Osteoarthritis of knee',
    'Weight management, physiotherapy, pain management',
    'Celecoxib 200mg (1 tablet daily), Glucosamine 1500mg (1 tablet daily)',
    'X-ray shows moderate joint space narrowing. Referred to physiotherapy. Consider intra-articular injection if conservative treatment fails.',
    180.00,
    'Completed'
WHERE NOT EXISTS (
    SELECT 1 FROM medical_records WHERE patient_id = 5 AND diagnosis LIKE 'Osteoarthritis%'
);

-- ============================================================================
-- Enable autovacuum for better performance
-- ============================================================================

ALTER TABLE users SET (autovacuum_enabled = true);
ALTER TABLE patients SET (autovacuum_enabled = true);
ALTER TABLE medical_records SET (autovacuum_enabled = true);
ALTER TABLE audit_log SET (autovacuum_enabled = true);