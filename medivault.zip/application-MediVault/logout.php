
<?php

define('MEDIVAULT_APP', true);
require_once 'config.php';
require_once 'includes/session.php';

if (isLoggedIn()) {
    $conn = getDBConnection();
    
    if ($conn !== false) {
        $userId = getCurrentUserId();
        $username = getCurrentUsername();
        
        // Log logout action
        insertAuditLog($conn, $userId, 'LOGOUT', 'Users', $userId, 
                       "User {$username} logged out");
        
        closeDBConnection($conn);
    }
    
    // Destroy session
    destroyUserSession();
}

// Redirect to login page
redirect('index.php?success=You have been logged out successfully');

?>