<?php
/**
 * MediVault Login Page - PostgreSQL Version
 * Updated to use PDO with prepared statements
 */

define('MEDIVAULT_APP', true);
require_once 'config.php';
require_once 'includes/session.php';

// Redirect if already logged in
if (isLoggedIn()) {
    $dashboardUrl = getDashboardUrl();
    header("Location: " . BASE_URL . $dashboardUrl);
    exit();
}

$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitizeInput($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password';
    } else {
        $conn = getDBConnection();
        
        if ($conn === false) {
            $error = 'Database connection failed. Please try again later.';
            logError("Login page: Database connection failed");
        } else {
            // PostgreSQL prepared statement - NO stored procedures
            $query = "
                SELECT u.user_id, u.username, u.password_hash, u.email, u.is_active,
                       u.failed_login_attempts, u.last_failed_login, r.role_name
                FROM users u
                INNER JOIN roles r ON u.role_id = r.role_id
                WHERE u.username = ?
            ";
            
            $result = executeQuery($conn, $query, [$username]);
            
            if ($result && count($result) > 0) {
                $user = $result[0];
                
                // Check if account is active
                if ($user['is_active'] == false) {
                    $error = 'Your account has been locked. Please contact administrator.';
                    insertAuditLog($conn, null, 'LOGIN_FAILED', 'users', null, 
                        "Login attempt on locked account: {$username} from IP: " . $_SERVER['REMOTE_ADDR']);
                }
                // Check if too many recent failures
                elseif ($user['failed_login_attempts'] >= MAX_LOGIN_ATTEMPTS) {
                    // Lock the account
                    $lockQuery = "UPDATE users SET is_active = false WHERE user_id = ?";
                    executeNonQuery($conn, $lockQuery, [$user['user_id']]);
                    
                    $error = "Account locked due to multiple failed login attempts.";
                }
                // Verify password
                elseif (verifyPassword($password, $user['password_hash'])) {
                    // *** Set session ***
                    setUserSession(
                        $user['user_id'],
                        $user['username'],
                        $user['role_name'],
                        $user['email']
                    );
                    
                    // Update last login and reset failed attempts
                    $updateQuery = "
                        UPDATE users 
                        SET last_login = CURRENT_TIMESTAMP,
                            failed_login_attempts = 0,
                            last_failed_login = NULL
                        WHERE user_id = ?
                    ";
                    executeNonQuery($conn, $updateQuery, [$user['user_id']]);
                    
                    // Log successful login
                    insertAuditLog($conn, $user['user_id'], 'LOGIN', 'users', $user['user_id'], 
                                  'User logged in successfully');
                    
                    closeDBConnection($conn);
                    
                    // Redirect to dashboard
                    $dashboardUrl = getDashboardUrl($user['role_name']);
                    header("Location: " . BASE_URL . $dashboardUrl);
                    exit();
                } else {
                    // Failed login - increment counter
                    $failQuery = "
                        UPDATE users 
                        SET failed_login_attempts = failed_login_attempts + 1,
                            last_failed_login = CURRENT_TIMESTAMP
                        WHERE user_id = ?
                    ";
                    executeNonQuery($conn, $failQuery, [$user['user_id']]);
                    
                    $error = 'Invalid username or password';
                    insertAuditLog($conn, null, 'LOGIN_FAILED', 'users', null, 
                        "Failed login attempt for username: $username from IP: " . $_SERVER['REMOTE_ADDR']);
                    
                    $remaining = MAX_LOGIN_ATTEMPTS - ($user['failed_login_attempts'] + 1);
                    if ($remaining > 0 && $remaining <= 2) {
                        $error .= ". {$remaining} attempt(s) remaining before account lockout.";
                    }
                }
            } else {
                $error = 'Invalid username or password';
                insertAuditLog($conn, null, 'LOGIN_FAILED', 'users', null, 
                    "Failed login attempt for username: $username from IP: " . $_SERVER['REMOTE_ADDR']);
            }
            
            closeDBConnection($conn);
        }
    }
}

// Get messages from URL
if (isset($_GET['error'])) {
    $error = sanitizeInput($_GET['error']);
}

if (isset($_GET['success'])) {
    $success = sanitizeInput($_GET['success']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo APP_NAME; ?></title>
    
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            max-width: 450px;
            width: 100%;
        }
        
        .login-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 30px;
            text-align: center;
            border-radius: 15px 15px 0 0;
        }
        
        .login-body {
            padding: 40px;
        }
        
        .btn-login {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="login-header">
            <i class="bi bi-heart-pulse-fill" style="font-size: 3rem;"></i>
            <h2>MediVault</h2>
            <p>Secure Patient Record Management</p>
        </div>
        
        <div class="login-body">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="bi bi-exclamation-triangle-fill"></i> <?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="bi bi-check-circle-fill"></i> <?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="username" name="username" 
                           placeholder="Username" required autofocus>
                    <label><i class="bi bi-person-fill"></i> Username</label>
                </div>
                
                <div class="form-floating mb-3">
                    <input type="password" class="form-control" id="password" name="password"
                           placeholder="Password" required>
                    <label><i class="bi bi-lock-fill"></i> Password</label>
                </div>
                
                <button type="submit" class="btn btn-primary btn-login">
                    <i class="bi bi-box-arrow-in-right"></i> Login
                </button>
            </form>
            
            <!-- Demo Credentials -->
            <div class="mt-4 p-3 bg-light rounded">
                <h6><i class="bi bi-info-circle-fill"></i> Demo Credentials</h6>
                <div class="credential-item">
                    <strong>Admin:</strong> mvadmin / Admin@MediVault2025!
                </div>
                <div class="credential-item">
                    <strong>Doctor:</strong> dr.wong / DoctorWong@MediVault2025!
                </div>
                <div class="credential-item">
                    <strong>Reception:</strong> reception / Reception@MediVault2025!
                </div>
                <div class="credential-item">
                    <strong>Auditor:</strong> auditor1 / Auditor@MediVault2025!
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
