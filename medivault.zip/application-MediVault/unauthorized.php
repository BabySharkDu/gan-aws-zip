<?php
define('MEDIVAULT_APP', true);
require_once 'config.php';
require_once 'includes/session.php';

$pageTitle = 'Unauthorized Access';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unauthorized - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card border-danger">
                    <div class="card-header bg-danger text-white">
                        <h4><i class="bi bi-exclamation-triangle-fill"></i> Unauthorized Access</h4>
                    </div>
                    <div class="card-body text-center">
                        <i class="bi bi-shield-x" style="font-size: 5rem; color: #dc3545;"></i>
                        <h5 class="mt-3">Access Denied</h5>
                        <p class="text-muted">You do not have permission to access this page.</p>
                        
                        <?php if (isLoggedIn()): ?>
                            <p>Your role: <strong><?php echo getCurrentRole(); ?></strong></p>
                            <a href="<?php echo BASE_URL . getDashboardUrl(); ?>" class="btn btn-primary">
                                <i class="bi bi-house-door-fill"></i> Go to Dashboard
                            </a>
                        <?php else: ?>
                            <a href="<?php echo BASE_URL; ?>index.php" class="btn btn-primary">
                                <i class="bi bi-box-arrow-in-right"></i> Login
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>