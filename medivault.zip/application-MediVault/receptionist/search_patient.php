<?php
/**
 * Receptionist - Search Patient
 * Advanced patient search with multiple criteria
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

// Require Receptionist role
requireRole('Receptionist');
$pageTitle = 'Search Patients';

// Get search parameters

$searchName = sanitizeInput($_GET['name'] ?? '');
$searchGender = sanitizeInput($_GET['gender'] ?? '');
$searchBloodType = sanitizeInput($_GET['blood_type'] ?? '');
$searchDateFrom = sanitizeInput($_GET['date_from'] ?? '');
$searchDateTo = sanitizeInput($_GET['date_to'] ?? '');

$conn = getDBConnection();
$patients = array();
$searchPerformed = false;

if ($conn !== false && (!empty($searchName) || !empty($searchGender) || !empty($searchBloodType) || !empty($searchDateFrom))) {
    $searchPerformed = true;
    
    $whereClauses = [];
    $params = [];

    // Filter by name (case-insensitive)
    if (!empty($searchName)) {
        $whereClauses[] = "p.full_name ILIKE ?";
        $params[] = "%$searchName%";
    }
    
    // Filter by gender
    if (!empty($searchGender)) {
        $whereClauses[] = "p.gender = ?";
        $params[] = $searchGender;
    }

    // Filter by blood type
    if (!empty($searchBloodType)) {
        $whereClauses[] = "p.blood_type = ?";
        $params[] = $searchBloodType;
    }

    // Filter by registration date range
    if (!empty($searchDateFrom)) {
        $whereClauses[] = "DATE(p.registered_date) >= ?";
        $params[] = $searchDateFrom;
    }
    if (!empty($searchDateTo)) {
        $whereClauses[] = "DATE(p.registered_date) <= ?";
        $params[] = $searchDateTo;
    }

    $whereSQL = !empty($whereClauses) ? 'WHERE ' . implode(' AND ', $whereClauses) : '';

    $query = "SELECT p.patient_id AS \"PatientID\", p.full_name AS \"FullName\", 
                     p.date_of_birth AS \"DateOfBirth\", p.gender AS \"Gender\", 
                     p.blood_type AS \"BloodType\", p.emergency_contact AS \"EmergencyContact\", 
                     p.registered_date AS \"RegisteredDate\"
              FROM patients p
              $whereSQL
              ORDER BY p.full_name ASC";

    $patients = executeQuery($conn, $query, $params);

    // Log activity
    $searchDetails = "Receptionist searched patients: Name={$searchName}, Gender={$searchGender}, BloodType={$searchBloodType}";
    insertAuditLog($conn, getCurrentUserId(), 'SELECT', 'patients', null, $searchDetails);

    closeDBConnection($conn);
}

include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-search"></i> Advanced Patient Search</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item active">Search Patients</li>
        </ol>
    </nav>
</div>

<!-- Search Form -->
<div class="card mb-3">
    <div class="card-header">
        <i class="bi bi-funnel-fill"></i> Search Criteria
    </div>
    <div class="card-body">
        <form method="GET" action="" class="row g-3">
            <div class="col-md-6">
                <label for="name" class="form-label">
                    <i class="bi bi-person-fill"></i> Patient Name
                </label>
                <input type="text" class="form-control" id="name" name="name" 
                       placeholder="Enter full name or partial name..."
                       value="<?php echo htmlspecialchars($searchName); ?>">
                <small class="text-muted">Leave empty to search all patients</small>
            </div>
            
            <div class="col-md-3">
                <label for="gender" class="form-label">
                    <i class="bi bi-gender-ambiguous"></i> Gender
                </label>
                <select class="form-select" id="gender" name="gender">
                    <option value="">All Genders</option>
                    <option value="M" <?php echo ($searchGender === 'M') ? 'selected' : ''; ?>>Male</option>
                    <option value="F" <?php echo ($searchGender === 'F') ? 'selected' : ''; ?>>Female</option>
                    <option value="O" <?php echo ($searchGender === 'O') ? 'selected' : ''; ?>>Other</option>
                </select>
            </div>
            
            <div class="col-md-3">
                <label for="blood_type" class="form-label">
                    <i class="bi bi-droplet-fill"></i> Blood Type
                </label>
                <select class="form-select" id="blood_type" name="blood_type">
                    <option value="">All Blood Types</option>
                    <?php 
                    $bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
                    foreach ($bloodTypes as $type): 
                    ?>
                        <option value="<?php echo $type; ?>" 
                            <?php echo ($searchBloodType === $type) ? 'selected' : ''; ?>>
                            <?php echo $type; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-6">
                <label for="date_from" class="form-label">
                    <i class="bi bi-calendar-event"></i> Registered From
                </label>
                <input type="date" class="form-control" id="date_from" name="date_from" 
                       value="<?php echo htmlspecialchars($searchDateFrom); ?>">
            </div>
            
            <div class="col-md-6">
                <label for="date_to" class="form-label">
                    <i class="bi bi-calendar-event-fill"></i> Registered To
                </label>
                <input type="date" class="form-control" id="date_to" name="date_to" 
                       value="<?php echo htmlspecialchars($searchDateTo); ?>">
            </div>
            
            <div class="col-12">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-search"></i> Search Patients
                </button>
                <a href="search_patient.php" class="btn btn-secondary">
                    <i class="bi bi-x-circle"></i> Clear Search
                </a>
                <a href="register_patient.php" class="btn btn-success">
                    <i class="bi bi-person-plus-fill"></i> Register New Patient
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Search Results -->
<?php if ($searchPerformed): ?>
    <div class="card">
        <div class="card-header">
            <i class="bi bi-list-ul"></i> Search Results
            <span class="badge bg-info float-end"><?php echo count($patients); ?> patients found</span>
        </div>
        <div class="card-body">
            <?php if (!empty($patients)): ?>
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead class="table-success">
                            <tr>
                                <th>Patient ID</th>
                                <th>Full Name</th>
                                <th>Date of Birth</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Blood Type</th>
                                <th>Emergency Contact</th>
                                <th>Registered</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($patients as $patient): ?>
                                <tr>
                                    <td>
                                        <strong class="text-success">P-<?php echo str_pad($patient['PatientID'], 5, '0', STR_PAD_LEFT); ?></strong>
                                    </td>
                                    <td>
                                        <i class="bi bi-person-circle"></i> 
                                        <strong><?php echo htmlspecialchars($patient['FullName']); ?></strong>
                                    </td>
                                    <td>
                                        <?php 
                                        if ($patient['DateOfBirth']) {
                                            echo date('d M Y', strtotime($patient['DateOfBirth']));
                                        } else {
                                            echo "<span class='text-muted'>N/A</span>";
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                        if ($patient['DateOfBirth']) {
                                            $dob = new DateTime($patient['DateOfBirth']);
                                            $age = $dob->diff(new DateTime())->y;
                                            echo "<small class='text-muted'>{$age} years</small>";
                                        } else {
                                            echo "<span class='text-muted'>-</span>";
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $genderIcon = '';
                                        $genderText = '';
                                        switch($patient['Gender']) {
                                            case 'M':
                                                $genderIcon = 'bi-gender-male text-primary';
                                                $genderText = 'Male';
                                                break;
                                            case 'F':
                                                $genderIcon = 'bi-gender-female text-danger';
                                                $genderText = 'Female';
                                                break;
                                            default:
                                                $genderIcon = 'bi-gender-ambiguous text-secondary';
                                                $genderText = 'Other';
                                        }
                                        ?>
                                        <i class="bi <?php echo $genderIcon; ?>"></i> <?php echo $genderText; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($patient['BloodType'])): ?>
                                            <span class="badge bg-danger">
                                                <?php echo htmlspecialchars($patient['BloodType']); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">Unknown</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <small><?php echo htmlspecialchars($patient['EmergencyContact'] ?? 'N/A'); ?></small>
                                    </td>
                                    <td>
                                        <small><?php echo date('d M Y', strtotime($patient['RegisteredDate'])); ?></small>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    <i class="bi bi-exclamation-triangle-fill"></i> 
                    No patients found matching your search criteria. Try adjusting your filters.
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php else: ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle-fill"></i> 
        Enter search criteria above and click "Search Patients" to find patient records.
    </div>
<?php endif; ?>

<!-- Search Tips -->
<div class="card mt-3">
    <div class="card-header">
        <i class="bi bi-lightbulb-fill"></i> Search Tips
    </div>
    <div class="card-body">
        <ul>
            <li><strong>Name Search:</strong> You can search by full name or partial name (e.g., "Ahmad" will find "Ahmad bin Abdullah")</li>
            <li><strong>Multiple Criteria:</strong> Combine filters to narrow down results (e.g., Male patients with O+ blood type)</li>
            <li><strong>Date Range:</strong> Use date filters to find patients registered within a specific time period</li>
            <li><strong>Leave Empty:</strong> Leave all fields empty and search to see all patients</li>
        </ul>
    </div>
</div>

<?php
include '../includes/footer.php';
?>