<?php
/**
 * Receptionist - Register New Patient
 * Demonstrates encrypted data insertion and prepared statements
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

// Require Receptionist role
requireRole('Receptionist');

$pageTitle = 'Register New Patient';
$errors = array();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $errors[] = 'Invalid security token.';
    } else {
        $fullName = sanitizeInput($_POST['full_name'] ?? '');
        $icNumber = sanitizeInput($_POST['ic_number'] ?? ''); // Plaintext from form
        $dateOfBirth = sanitizeInput($_POST['date_of_birth'] ?? '');
        $gender = sanitizeInput($_POST['gender'] ?? '');
        $phoneNumber = sanitizeInput($_POST['phone_number'] ?? ''); // Plaintext from form
        $address = sanitizeInput($_POST['address'] ?? '');
        $bloodType = sanitizeInput($_POST['blood_type'] ?? '');
        $emergencyContact = sanitizeInput($_POST['emergency_contact'] ?? '');
        
        // Basic validation
        if (empty($fullName) || empty($icNumber) || empty($phoneNumber)) {
            $errors[] = 'Required fields are missing';
        }
        
        if (empty($errors)) {
            $conn = getDBConnection();
            if ($conn !== false) {
                // IMPORTANT: Use pgp_sym_encrypt via our helper in config.php
                // This converts plaintext to BYTEA for the patients table
                $icEncrypted = encryptData($icNumber); 
                $phoneEncrypted = encryptData($phoneNumber);

                $query = "INSERT INTO patients (full_name, ic_number_encrypted, date_of_birth, gender, 
                                               phone_number_encrypted, address, blood_type, 
                                               emergency_contact, registered_by) 
                          VALUES (?, $1, ?, ?, $2, ?, ?, ?, ?) RETURNING patient_id";
                
                // Note: Since encryptData returns a resource/string, we pass them carefully
                try {
                    $stmt = $conn->prepare("INSERT INTO patients (full_name, ic_number_encrypted, date_of_birth, gender, phone_number_encrypted, address, blood_type, emergency_contact, registered_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING patient_id");
                    
                    // We decode the base64 from encryptData back to binary for the BYTEA column
                    $stmt->execute([
                        $fullName, 
                        base64_decode($icEncrypted), 
                        $dateOfBirth, 
                        $gender, 
                        base64_decode($phoneEncrypted), 
                        $address, 
                        $bloodType, 
                        $emergencyContact, 
                        getCurrentUserId()
                    ]);

                    $newPatientId = $stmt->fetch()['patient_id'];
                    insertAuditLog($conn, getCurrentUserId(), 'INSERT', 'patients', $newPatientId, "Registered patient: $fullName");
                    
                    showSuccess("Patient registered successfully! ID: $newPatientId");
                    closeDBConnection($conn);
                    redirect("/receptionist/dashboard.php");
                } catch (Exception $e) {
                    $errors[] = 'Database error: ' . $e->getMessage();
                }
            }
        }
    }
}
$csrfToken = generateCSRFToken();
include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-person-plus-fill"></i> Register New Patient</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item active">Register Patient</li>
        </ol>
    </nav>
</div>

<div class="row">
    <div class="col-md-10 mx-auto">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-clipboard-plus"></i> Patient Registration Form
            </div>
            <div class="card-body">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle-fill"></i> <strong>Please correct the following errors:</strong>
                        <ul class="mb-0 mt-2">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="" id="patientForm">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    
                    <!-- Personal Information -->
                    <h5 class="border-bottom pb-2 mb-3">
                        <i class="bi bi-person-circle"></i> Personal Information
                    </h5>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="full_name" class="form-label">
                                Full Name <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" id="full_name" name="full_name" 
                                   value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>" 
                                   required>
                        </div>
                        
                        <div class="col-md-6">
                            <label for="ic_number" class="form-label">
                                IC Number <span class="text-danger">*</span>
                                <small class="text-muted">(Format: XXXXXX-XX-XXXX)</small>
                            </label>
                            <input type="text" class="form-control" id="ic_number" name="ic_number" 
                                   placeholder="950101-10-1234"
                                   value="<?php echo htmlspecialchars($_POST['ic_number'] ?? ''); ?>" 
                                   pattern="\d{6}-\d{2}-\d{4}" required>
                            <small class="text-info">
                                <i class="bi bi-shield-lock-fill"></i> This field will be encrypted
                            </small>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="date_of_birth" class="form-label">
                                Date of Birth <span class="text-danger">*</span>
                            </label>
                            <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" 
                                   value="<?php echo htmlspecialchars($_POST['date_of_birth'] ?? ''); ?>" 
                                   max="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="col-md-4">
                            <label for="gender" class="form-label">
                                Gender <span class="text-danger">*</span>
                            </label>
                            <select class="form-select" id="gender" name="gender" required>
                                <option value="">Select Gender</option>
                                <option value="M" <?php echo (($_POST['gender'] ?? '') === 'M') ? 'selected' : ''; ?>>Male</option>
                                <option value="F" <?php echo (($_POST['gender'] ?? '') === 'F') ? 'selected' : ''; ?>>Female</option>
                                <option value="O" <?php echo (($_POST['gender'] ?? '') === 'O') ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                        
                        <div class="col-md-4">
                            <label for="blood_type" class="form-label">Blood Type</label>
                            <select class="form-select" id="blood_type" name="blood_type">
                                <option value="">Select Blood Type</option>
                                <?php 
                                $bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
                                foreach ($bloodTypes as $type): 
                                ?>
                                    <option value="<?php echo $type; ?>" 
                                        <?php echo (($_POST['blood_type'] ?? '') === $type) ? 'selected' : ''; ?>>
                                        <?php echo $type; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Contact Information -->
                    <h5 class="border-bottom pb-2 mb-3 mt-4">
                        <i class="bi bi-telephone-fill"></i> Contact Information
                    </h5>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="phone_number" class="form-label">
                                Phone Number <span class="text-danger">*</span>
                                <small class="text-muted">(Format: XXX-XXXXXXX)</small>
                            </label>
                            <input type="text" class="form-control" id="phone_number" name="phone_number" 
                                   placeholder="012-3456789"
                                   value="<?php echo htmlspecialchars($_POST['phone_number'] ?? ''); ?>" 
                                   pattern="\d{3}-\d{7,8}" required>
                            <small class="text-info">
                                <i class="bi bi-shield-lock-fill"></i> This field will be encrypted
                            </small>
                        </div>
                        
                        <div class="col-md-6">
                            <label for="emergency_contact" class="form-label">Emergency Contact</label>
                            <input type="text" class="form-control" id="emergency_contact" name="emergency_contact" 
                                   placeholder="Name & Phone Number"
                                   value="<?php echo htmlspecialchars($_POST['emergency_contact'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <textarea class="form-control" id="address" name="address" rows="3"><?php echo htmlspecialchars($_POST['address'] ?? ''); ?></textarea>
                    </div>
                    
                    <!-- Submit Buttons -->
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                        <button type="reset" class="btn btn-secondary">
                            <i class="bi bi-x-circle"></i> Clear Form
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-check-circle-fill"></i> Register Patient
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Security Notice -->
        <div class="alert alert-info mt-3">
            <i class="bi bi-shield-check"></i> <strong>Security Notice:</strong> 
            Sensitive information (IC Number, Phone Number) is encrypted using AES-256 before storage. 
            All data insertions are logged for audit purposes.
        </div>
    </div>
</div>

<script>
// Client-side validation
document.getElementById('patientForm').addEventListener('submit', function(e) {
    const icNumber = document.getElementById('ic_number').value;
    const phoneNumber = document.getElementById('phone_number').value;
    
    // Validate IC number format
    const icPattern = /^\d{6}-\d{2}-\d{4}$/;
    if (!icPattern.test(icNumber)) {
        alert('IC Number must be in format: XXXXXX-XX-XXXX');
        e.preventDefault();
        return false;
    }
    
    // Validate phone number format
    const phonePattern = /^\d{3}-\d{7,8}$/;
    if (!phonePattern.test(phoneNumber)) {
        alert('Phone Number must be in format: XXX-XXXXXXX');
        e.preventDefault();
        return false;
    }
});

// Auto-format IC number
document.getElementById('ic_number').addEventListener('input', function(e) {
    let value = e.target.value.replace(/[^0-9]/g, '');
    if (value.length > 6) {
        value = value.slice(0, 6) + '-' + value.slice(6);
    }
    if (value.length > 9) {
        value = value.slice(0, 9) + '-' + value.slice(9);
    }
    e.target.value = value.slice(0, 15);
});

// Auto-format phone number
document.getElementById('phone_number').addEventListener('input', function(e) {
    let value = e.target.value.replace(/[^0-9]/g, '');
    if (value.length > 3) {
        value = value.slice(0, 3) + '-' + value.slice(3);
    }
    e.target.value = value.slice(0, 12);
});
</script>

<?php
include '../includes/footer.php';
?>