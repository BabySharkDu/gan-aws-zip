<?php
/**
 * Receptionist Dashboard
 * Overview of patient registration statistics
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

// Require Receptionist role
requireRole('Receptionist');
$pageTitle = 'Receptionist Dashboard';
$conn = getDBConnection();

// Get statistics
$stats = array(
    'total_patients' => 0,
    'today_registrations' => 0,
    'this_week' => 0,
    'this_month' => 0
);

$recentPatients = array();

if ($conn !== false) {
    $statsQuery = "SELECT 
        COUNT(*) as total_patients,
        COUNT(*) FILTER (WHERE DATE(registered_date) = CURRENT_DATE) as today_registrations,
        COUNT(*) FILTER (WHERE registered_date >= CURRENT_DATE - INTERVAL '7 days') as this_week,
        COUNT(*) FILTER (WHERE DATE_TRUNC('month', registered_date) = DATE_TRUNC('month', CURRENT_DATE)) as this_month
        FROM patients";
    
    $res = executeQuery($conn, $statsQuery);
    if ($res) {
        $stats = [
            'total_patients'      => $res[0]['total_patients'],
            'today_registrations' => $res[0]['today_registrations'],
            'this_week'           => $res[0]['this_week'],
            'this_month'          => $res[0]['this_month']
        ];
    }

    $recentQuery = "SELECT p.patient_id as \"PatientID\", p.full_name as \"FullName\", 
                           p.gender as \"Gender\", p.registered_date as \"RegisteredDate\", 
                           u.username as \"RegisteredBy\"
                    FROM patients p
                    LEFT JOIN users u ON p.registered_by = u.user_id
                    ORDER BY p.registered_date DESC LIMIT 10";
    $recentPatients = executeQuery($conn, $recentQuery);
    
    closeDBConnection($conn);
}

include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-speedometer2"></i> Receptionist Dashboard</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </nav>
</div>

<!-- Statistics Cards -->
<div class="row">
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-success">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">Total Patients</h6>
                        <h2 class="mb-0"><?php echo $stats['total_patients']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-people-fill" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <a href="view_patients.php" class="text-white text-decoration-none">
                    View all patients <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">Today</h6>
                        <h2 class="mb-0"><?php echo $stats['today_registrations']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-calendar-check-fill" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <span class="text-white">Registered today</span>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-info">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">This Week</h6>
                        <h2 class="mb-0"><?php echo $stats['this_week']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-calendar-week-fill" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <span class="text-white">Last 7 days</span>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">This Month</h6>
                        <h2 class="mb-0"><?php echo $stats['this_month']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-calendar-month-fill" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <span class="text-white"><?php echo date('F Y'); ?></span>
            </div>
        </div>
    </div>
</div>

<!-- Recent Patients -->
<div class="card mb-4">
    <div class="card-header">
        <i class="bi bi-clock-history"></i> Recently Registered Patients
    </div>
    <div class="card-body">
        <?php if (!empty($recentPatients)): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Patient ID</th>
                            <th>Full Name</th>
                            <th>Gender</th>
                            <th>Registered Date</th>
                            <th>Registered By</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentPatients as $patient): ?>
                            <tr>
                                <td>
                                    <strong class="text-primary">
                                        P-<?php echo str_pad($patient['PatientID'], 5, '0', STR_PAD_LEFT); ?>
                                    </strong>
                                </td>
                                <td>
                                    <i class="bi bi-person-circle"></i> 
                                    <?php echo htmlspecialchars($patient['FullName'] ?? ''); ?>
                                </td>
                                <td>
                                    <?php
                                    $icon = $patient['Gender'] === 'M' ? 'bi-gender-male text-primary' : 'bi-gender-female text-danger';
                                    $text = $patient['Gender'] === 'M' ? 'Male' : 'Female';
                                    ?>
                                    <i class="bi <?php echo $icon; ?>"></i> <?php echo $text; ?>
                                </td>
                                <td>
                                    <small><?php echo date('d M Y, h:i A', strtotime($patient['RegisteredDate'])); ?></small>
                                </td>
                                <td>
                                    <small class="text-muted"><?php echo htmlspecialchars($patient['RegisteredBy'] ?? ''); ?></small>
                                </td>
                                <td>
                                    <a href="view_patients.php?id=<?php echo $patient['PatientID']; ?>" 
                                       class="btn btn-sm btn-info">
                                        <i class="bi bi-eye-fill"></i> View
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted">No patients registered yet.</p>
        <?php endif; ?>
    </div>
</div>

<!-- Quick Actions -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-lightning-fill"></i> Quick Actions
    </div>
    <div class="card-body">
        <div class="d-grid gap-2 d-md-flex">
            <a href="register_patient.php" class="btn btn-primary btn-lg">
                <i class="bi bi-person-plus-fill"></i> Register New Patient
            </a>
            <a href="view_patients.php" class="btn btn-success btn-lg">
                <i class="bi bi-list-ul"></i> View All Patients
            </a>
            <a href="view_patients.php?search=" class="btn btn-info btn-lg text-white">
                <i class="bi bi-search"></i> Search Patients
            </a>
        </div>
    </div>
</div>

<!-- Access Notice -->
<div class="alert alert-info mt-3">
    <i class="bi bi-info-circle-fill"></i> <strong>Access Level:</strong> 
    As a receptionist, you can register patients and view their contact information, but you cannot access medical records or diagnoses.
</div>

<?php
include '../includes/footer.php';
?>