<?php
define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

requireRole('Receptionist');

$pageTitle = 'Edit Patient';
$errors = array();
// Get patient ID
$patientId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($patientId === 0) {
    showError('Invalid patient ID');
    redirect('/receptionist/view_patients.php');
}

// Get database connection
$conn = getDBConnection();
$patient = null;

if ($conn !== false && $patientId > 0) {
    // Get patient details (Limited view for receptionist)
    $query = "SELECT patient_id as \"PatientID\", full_name as \"FullName\", 
                     date_of_birth as \"DateOfBirth\", gender as \"Gender\", 
                     address as \"Address\", blood_type as \"BloodType\", 
                     emergency_contact as \"EmergencyContact\"
              FROM patients WHERE patient_id = ?";
    $res = executeQuery($conn, $query, [$patientId]);
    if ($res) { $patient = $res[0]; }
}

if (!$patient) {
    showError('Patient not found');
    redirect('/receptionist/view_patients.php');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (verifyCSRFToken($_POST['csrf_token'])) {
        $fullName = sanitizeInput($_POST['full_name']);
        $dob = sanitizeInput($_POST['date_of_birth']);
        $gender = sanitizeInput($_POST['gender']);
        $address = sanitizeInput($_POST['address']);
        $blood = sanitizeInput($_POST['blood_type']);
        $emergency = sanitizeInput($_POST['emergency_contact']);

        $updateQuery = "UPDATE patients SET full_name = ?, date_of_birth = ?, gender = ?, 
                                           address = ?, blood_type = ?, emergency_contact = ? 
                        WHERE patient_id = ?";
        
        $result = executeNonQuery($conn, $updateQuery, [$fullName, $dob, $gender, $address, $blood, $emergency, $patientId]);

        if ($result !== false) {
            insertAuditLog($conn, getCurrentUserId(), 'UPDATE', 'patients', $patientId, "Updated patient info: $fullName");
            showSuccess("Patient updated successfully");
            closeDBConnection($conn);
            redirect("view_patients.php");
        } else {
            $errors[] = "Update failed.";
        }
    }
}

$csrfToken = generateCSRFToken();
if ($conn !== false) { closeDBConnection($conn); }
include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-pencil-square"></i> Edit Patient Information</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="view_patients.php">Patients</a></li>
            <li class="breadcrumb-item active">Edit Patient</li>
        </ol>
    </nav>
</div>

<div class="row">
    <div class="col-md-10 mx-auto">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-clipboard-data"></i> Update Patient Details - P-<?php echo str_pad($patientId, 5, '0', STR_PAD_LEFT); ?>
            </div>
            <div class="card-body">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    
                    <div class="alert alert-warning">
                        <i class="bi bi-exclamation-triangle-fill"></i> <strong>Notice:</strong>
                        You can only update non-sensitive information. IC Number and Phone Number cannot be changed.
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="full_name" class="form-label">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="full_name" name="full_name" 
                                   value="<?php echo htmlspecialchars($patient['FullName']); ?>" required>
                        </div>
                        
                        <div class="col-md-3">
                            <label for="date_of_birth" class="form-label">Date of Birth <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" 
                                   value="<?php echo htmlspecialchars($patient['DateOfBirth']); ?>" 
                                   max="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="col-md-3">
                            <label for="gender" class="form-label">Gender <span class="text-danger">*</span></label>
                            <select class="form-select" id="gender" name="gender" required>
                                <option value="M" <?php echo ($patient['Gender'] === 'M') ? 'selected' : ''; ?>>Male</option>
                                <option value="F" <?php echo ($patient['Gender'] === 'F') ? 'selected' : ''; ?>>Female</option>
                                <option value="O" <?php echo ($patient['Gender'] === 'O') ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="blood_type" class="form-label">Blood Type</label>
                            <select class="form-select" id="blood_type" name="blood_type">
                                <option value="">Unknown</option>
                                <?php 
                                $bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
                                foreach ($bloodTypes as $type): 
                                ?>
                                    <option value="<?php echo $type; ?>" 
                                        <?php echo ($patient['BloodType'] === $type) ? 'selected' : ''; ?>>
                                        <?php echo $type; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-6">
                            <label for="emergency_contact" class="form-label">Emergency Contact</label>
                            <input type="text" class="form-control" id="emergency_contact" name="emergency_contact" 
                                   value="<?php echo htmlspecialchars($patient['EmergencyContact'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <textarea class="form-control" id="address" name="address" rows="3"><?php echo htmlspecialchars($patient['Address'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="view_patients.php" class="btn btn-secondary">
                            <i class="bi bi-x-circle"></i> Cancel
                        </a>
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-circle-fill"></i> Update Patient
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>