<?php
/**
 * Receptionist - View Patients (Limited Access)
 * Can only view contact information, NOT medical records
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

// Require Receptionist role
requireRole('Receptionist');
$pageTitle = 'View Patients';

// Get search parameter

$searchTerm = sanitizeInput($_GET['search'] ?? '');
$conn = getDBConnection();
$patients = array();

if ($conn !== false) {
    // Base query for limited view (Omit sensitive IC/Phone fields)
    $query = "SELECT p.patient_id AS \"PatientID\", p.full_name AS \"FullName\", 
                     p.date_of_birth AS \"DateOfBirth\", p.gender AS \"Gender\", 
                     p.blood_type AS \"BloodType\", p.address AS \"Address\", 
                     p.emergency_contact AS \"EmergencyContact\", p.registered_date AS \"RegisteredDate\"
              FROM patients p";
    $params = [];

    // Filter if search term is provided
    if (!empty($searchTerm)) {
        $query .= " WHERE p.full_name ILIKE ?";
        $params[] = "%$searchTerm%";
    }

    $query .= " ORDER BY p.registered_date DESC";
    $patients = executeQuery($conn, $query, $params);

    // Log the view action
    insertAuditLog($conn, getCurrentUserId(), 'SELECT', 'patients', null,
                "Receptionist viewed patient list" . (!empty($searchTerm) ? " (searched: {$searchTerm})" : ""));
                
    closeDBConnection($conn);
}

include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-list-ul"></i> Patient List</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item active">Patients</li>
        </ol>
    </nav>
</div>

<!-- Search and Actions -->
<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="" class="row g-3">
            <div class="col-md-8">
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" class="form-control" name="search" 
                           placeholder="Search by patient name..." 
                           value="<?php echo htmlspecialchars($searchTerm); ?>">
                    <button type="submit" class="btn btn-primary">Search</button>
                    <?php if (!empty($searchTerm)): ?>
                        <a href="view_patients.php" class="btn btn-secondary">Clear</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-4 text-end">
                <a href="register_patient.php" class="btn btn-success">
                    <i class="bi bi-person-plus-fill"></i> Register New Patient
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Patients Table -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-table"></i> Patient List (Contact Information Only)
        <?php if (!empty($searchTerm)): ?>
            <span class="badge bg-warning text-dark">Filtered Results</span>
        <?php endif; ?>
        <span class="badge bg-info"><?php echo count($patients); ?> patients</span>
    </div>
    <div class="card-body">
        <?php if (!empty($patients)): ?>
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="table-success">
                        <tr>
                            <th>Patient ID</th>
                            <th>Full Name</th>
                            <th>Date of Birth</th>
                            <th>Gender</th>
                            <th>Blood Type</th>
                            <th>Address</th>
                            <th>Emergency Contact</th>
                            <th>Registered</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($patients as $patient): ?>
                            <tr>
                                <td>
                                    <strong class="text-success">P-<?php echo str_pad($patient['PatientID'], 5, '0', STR_PAD_LEFT); ?></strong>
                                </td>
                                <td>
                                    <i class="bi bi-person-circle"></i> 
                                    <strong><?php echo htmlspecialchars($patient['FullName']); ?></strong>
                                </td>
                                <td>
                                    <?php 
                                    if ($patient['DateOfBirth']) {
                                        $dob = new DateTime($patient['DateOfBirth']);
                                        $age = $dob->diff(new DateTime())->y;
                                        echo $dob->format('d M Y') . " <small class='text-muted'>({$age} years)</small>";
                                    } else {
                                        echo "<span class='text-muted'>N/A</span>";
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    $genderIcon = '';
                                    $genderText = '';
                                    switch($patient['Gender']) {
                                        case 'M':
                                            $genderIcon = 'bi-gender-male text-primary';
                                            $genderText = 'Male';
                                            break;
                                        case 'F':
                                            $genderIcon = 'bi-gender-female text-danger';
                                            $genderText = 'Female';
                                            break;
                                        default:
                                            $genderIcon = 'bi-gender-ambiguous text-secondary';
                                            $genderText = 'Other';
                                    }
                                    ?>
                                    <i class="bi <?php echo $genderIcon; ?>"></i> <?php echo $genderText; ?>
                                </td>
                                <td>
                                    <?php if (!empty($patient['BloodType'])): ?>
                                        <span class="badge bg-danger">
                                            <?php echo htmlspecialchars($patient['BloodType']); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted">Unknown</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <small><?php echo htmlspecialchars($patient['Address'] ?? 'N/A'); ?></small>
                                </td>
                                <td>
                                    <small><?php echo htmlspecialchars($patient['EmergencyContact'] ?? 'N/A'); ?></small>
                                </td>
                                <td>
                                    <small><?php echo date('d M Y', strtotime($patient['RegisteredDate'])); ?></small>
                                </td>
                                <td>
                                    <a href="edit_patient.php?id=<?php echo $patient['PatientID']; ?>" 
                                    class="btn btn-sm btn-warning">
                                        <i class="bi bi-pencil-fill"></i> Edit
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                <i class="bi bi-exclamation-triangle-fill"></i> 
                <?php if (!empty($searchTerm)): ?>
                    No patients found matching "<?php echo htmlspecialchars($searchTerm); ?>"
                <?php else: ?>
                    No patients registered yet.
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Access Notice -->
<div class="alert alert-warning mt-3">
    <i class="bi bi-shield-exclamation"></i> <strong>Restricted Access:</strong> 
    As a receptionist, you can only view patient contact information. 
    <strong>You cannot access:</strong>
    <ul class="mb-0 mt-2">
        <li>IC Numbers (encrypted)</li>
        <li>Phone Numbers (encrypted)</li>
        <li>Medical records</li>
        <li>Diagnoses or treatment history</li>
    </ul>
    This restriction is enforced to protect patient privacy in compliance with PDPA 2010.
</div>

<?php
include '../includes/footer.php';
?>