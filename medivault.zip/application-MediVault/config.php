<?php
/**
 * MediVault Database Configuration - PostgreSQL Version
 * Updated for AWS RDS PostgreSQL deployment
 */

// Prevent direct access
if (!defined('MEDIVAULT_APP')) {
    define('MEDIVAULT_APP', true);
}

// ================================================================
// Load Environment Variables from .env file
// ================================================================
function loadEnv($filePath) {
    if (!file_exists($filePath)) {
        die("ERROR: .env file not found at: {$filePath}");
    }
    
    $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        // Skip comments
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        
        // Parse KEY=VALUE
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            
            // Remove quotes if present
            $value = trim($value, '"\'');
            
            // Set environment variable
            if (!array_key_exists($key, $_ENV)) {
                $_ENV[$key] = $value;
                putenv("{$key}={$value}");
            }
        }
    }
}

// Load .env file
$envPath = __DIR__ . '/.env';
loadEnv($envPath);

// Helper function to get environment variable
function env($key, $default = null) {
    $value = $_ENV[$key] ?? getenv($key);
    return $value !== false ? $value : $default;
}

// ================================================================
// Database Configuration
// ================================================================
define('DB_HOST', env('DB_HOST', 'localhost'));
define('DB_PORT', env('DB_PORT', '5432'));
define('DB_NAME', env('DB_NAME', 'medivault'));
define('DB_USER', env('DB_USER', 'medivault_app'));
define('DB_PASSWORD', env('DB_PASSWORD', ''));
define('DB_SSLMODE', env('DB_SSLMODE', 'require'));  // AWS RDS requires SSL

// Encryption key for sensitive data (IC numbers, phone numbers)
define('ENCRYPTION_KEY', env('ENCRYPTION_KEY', 'CHANGE_THIS_KEY_IN_PRODUCTION'));

// ================================================================
// Application Settings
// ================================================================
define('APP_NAME', env('APP_NAME', 'MediVault'));
define('APP_VERSION', env('APP_VERSION', '2.0.0'));
define('BASE_URL', env('BASE_URL', '/'));
define('APP_ENV', env('APP_ENV', 'production'));
define('APP_DEBUG', env('APP_DEBUG', 'false') === 'true');

// ================================================================
// Security Settings
// ================================================================
define('SESSION_TIMEOUT', (int)env('SESSION_TIMEOUT', 1800));
define('PASSWORD_MIN_LENGTH', (int)env('PASSWORD_MIN_LENGTH', 12));
define('MAX_LOGIN_ATTEMPTS', (int)env('MAX_LOGIN_ATTEMPTS', 5));
define('LOCKOUT_TIME', (int)env('LOCKOUT_TIME', 1800));

// ================================================================
// Error Reporting
// ================================================================
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);
}
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/logs/php_errors.log');

// ================================================================
// Timezone
// ================================================================
date_default_timezone_set('Asia/Kuala_Lumpur');

// ================================================================
// PDO Database Connection
// ================================================================

/**
 * Get Database Connection using PDO
 * @return PDO|false
 */
function getDBConnection() {
    static $conn = null;
    
    if ($conn !== null) {
        return $conn;
    }
    
    try {
        $dsn = sprintf(
            "pgsql:host=%s;port=%s;dbname=%s;sslmode=%s",
            DB_HOST,
            DB_PORT,
            DB_NAME,
            DB_SSLMODE
        );
        
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_PERSISTENT         => false  // Don't use persistent connections
        ];
        
        $conn = new PDO($dsn, DB_USER, DB_PASSWORD, $options);
        
        return $conn;
        
    } catch (PDOException $e) {
        logError("Database connection failed: " . $e->getMessage());
        return false;
    }
}

/**
 * Close Database Connection
 */
function closeDBConnection(&$conn) {
    $conn = null;
}

/**
 * Execute Query with Prepared Statement (SELECT)
 * @param PDO $conn
 * @param string $query
 * @param array $params
 * @return array|false
 */
function executeQuery($conn, $query, $params = []) {
    try {
        $stmt = $conn->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        logError("Query execution failed: " . $e->getMessage());
        return false;
    }
}

/**
 * Execute Non-Query (INSERT, UPDATE, DELETE)
 * @param PDO $conn
 * @param string $query
 * @param array $params
 * @return int|false Number of affected rows, or false on error
 */
function executeNonQuery($conn, $query, $params = []) {
    try {
        $stmt = $conn->prepare($query);
        $stmt->execute($params);
        return $stmt->rowCount();
    } catch (PDOException $e) {
        logError("Non-query execution failed: " . $e->getMessage());
        return false;
    }
}

/**
 * Get Last Insert ID
 * @param PDO $conn
 * @param string $sequence Sequence name (optional for PostgreSQL)
 * @return string|false
 */
function getLastInsertId($conn, $sequence = null) {
    try {
        return $conn->lastInsertId($sequence);
    } catch (PDOException $e) {
        logError("Failed to get last insert ID: " . $e->getMessage());
        return false;
    }
}

/**
 * Insert Audit Log
 * @param PDO $conn
 * @param int|null $userId
 * @param string $action
 * @param string $tableAffected
 * @param int|null $recordId
 * @param string|null $details
 * @return bool
 */
function insertAuditLog($conn, $userId, $action, $tableAffected, $recordId = null, $details = null) {
    $query = "SELECT log_audit($1, $2, $3, $4, $5)";
    
    $params = [
        $userId,
        $action,
        $tableAffected,
        $recordId,
        $details
    ];
    
    try {
        $stmt = $conn->prepare($query);
        $stmt->execute($params);
        return true;
    } catch (PDOException $e) {
        logError("Audit log insertion failed: " . $e->getMessage());
        return false;
    }
}

/**
 * Set Session Context (for audit logging)
 * Not needed in PostgreSQL - we pass user_id to functions directly
 */
function setSessionContext($conn, $userId) {
    // This was specific to MSSQL's SESSION_CONTEXT
    // In PostgreSQL, we pass user_id as function parameters
    // Keep function for compatibility but do nothing
    return true;
}

// ================================================================
// Encryption Functions (for IC Number and Phone Number)
// ================================================================

/**
 * Encrypt sensitive data
 * @param string $plaintext
 * @return string Base64-encoded encrypted data
 */
function encryptData($plaintext) {
    if (empty($plaintext)) {
        return '';
    }
    
    $conn = getDBConnection();
    if (!$conn) {
        return '';
    }
    
    try {
        $query = "SELECT encrypt_data($1, $2) as encrypted";
        $stmt = $conn->prepare($query);
        $stmt->execute([$plaintext, ENCRYPTION_KEY]);
        $result = $stmt->fetch();
        
        // Return base64-encoded binary data
        return base64_encode(stream_get_contents($result['encrypted']));
    } catch (PDOException $e) {
        logError("Encryption failed: " . $e->getMessage());
        return '';
    }
}

/**
 * Decrypt sensitive data
 * @param string $encrypted Base64-encoded encrypted data
 * @return string Decrypted plaintext
 */
function decryptData($encrypted) {
    if (empty($encrypted)) {
        return '';
    }
    
    $conn = getDBConnection();
    if (!$conn) {
        return '[DECRYPTION ERROR]';
    }
    
    try {
        // Decode base64 first
        $binary = base64_decode($encrypted);
        
        $query = "SELECT decrypt_data($1, $2) as decrypted";
        $stmt = $conn->prepare($query);
        $stmt->execute([$binary, ENCRYPTION_KEY]);
        $result = $stmt->fetch();
        
        return $result['decrypted'] ?? '[DECRYPTION ERROR]';
    } catch (PDOException $e) {
        logError("Decryption failed: " . $e->getMessage());
        return '[DECRYPTION ERROR]';
    }
}

// ================================================================
// Security Functions
// ================================================================

/**
 * Password Hashing (Argon2id)
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_ARGON2ID, [
        'memory_cost' => 65536,
        'time_cost' => 4,
        'threads' => 1
    ]);
}

/**
 * Password Verification
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Generate CSRF Token
 */
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF Token
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Sanitize Input
 */
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Validate Email
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Log Errors
 */
function logError($message) {
    $logFile = __DIR__ . '/logs/error_log.txt';
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[{$timestamp}] {$message}\n";
    
    if (!file_exists(__DIR__ . '/logs')) {
        mkdir(__DIR__ . '/logs', 0755, true);
    }
    
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}

/**
 * Redirect Function
 */
function redirect($url) {
    header("Location: " . BASE_URL . $url);
    exit();
}

/**
 * Display Success Message
 */
function showSuccess($message) {
    $_SESSION['success_message'] = $message;
}

/**
 * Display Error Message
 */
function showError($message) {
    $_SESSION['error_message'] = $message;
}

/**
 * Get and Clear Messages
 */
function getMessages() {
    $messages = [
        'success' => $_SESSION['success_message'] ?? null,
        'error' => $_SESSION['error_message'] ?? null
    ];
    
    unset($_SESSION['success_message']);
    unset($_SESSION['error_message']);
    
    return $messages;
}

// ================================================================
// Security Headers
// ================================================================
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Permissions-Policy: geolocation=(), microphone=(), camera=()");

$csp = "default-src 'self'; ";
$csp .= "script-src 'self' https://cdn.jsdelivr.net 'unsafe-inline'; ";
$csp .= "style-src 'self' https://cdn.jsdelivr.net 'unsafe-inline'; ";
$csp .= "img-src 'self' data:; ";
$csp .= "font-src 'self' https://cdn.jsdelivr.net;";
header("Content-Security-Policy: $csp");
?>