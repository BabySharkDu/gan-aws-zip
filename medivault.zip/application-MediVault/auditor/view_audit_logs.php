<?php
/**
 * Auditor - View Audit Logs
 * FIXED: Now correctly uses all filter parameters including Username
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

requireRole('Auditor');
$pageTitle = 'Audit Logs';

$filterAction = sanitizeInput($_GET['action'] ?? '');
$filterUsername = sanitizeInput($_GET['user'] ?? ''); 
$filterTable = sanitizeInput($_GET['table'] ?? '');
$filterDateFrom = sanitizeInput($_GET['date_from'] ?? '');
$filterDateTo = sanitizeInput($_GET['date_to'] ?? '');

$conn = getDBConnection();
$auditLogs = array();
$users = array();
$tables = array();

if ($conn !== false) {
    // Build Dynamic Filter
    $whereClauses = [];
    $params = [];

    if (!empty($filterAction)) {
        $whereClauses[] = "a.action = ?";
        $params[] = $filterAction;
    }
    if (!empty($filterUsername)) {
        $whereClauses[] = "u.username = ?";
        $params[] = $filterUsername;
    }
    if (!empty($filterTable)) {
        $whereClauses[] = "a.table_affected = ?";
        $params[] = $filterTable;
    }
    if (!empty($filterDateFrom)) {
        $whereClauses[] = "DATE(a.timestamp) >= ?";
        $params[] = $filterDateFrom;
    }
    if (!empty($filterDateTo)) {
        $whereClauses[] = "DATE(a.timestamp) <= ?";
        $params[] = $filterDateTo;
    }

    $whereSQL = !empty($whereClauses) ? 'WHERE ' . implode(' AND ', $whereClauses) : '';

    // Main Log Query
    $query = "SELECT a.log_id as \"LogID\", a.timestamp as \"Timestamp\", u.username as \"Username\", 
                     a.action as \"Action\", a.table_affected as \"TableAffected\", 
                     a.record_id as \"RecordID\", a.ip_address as \"IPAddress\", a.details as \"Details\"
              FROM audit_log a
              LEFT JOIN users u ON a.user_id = u.user_id
              $whereSQL
              ORDER BY a.timestamp DESC
              LIMIT 100";

    $auditLogs = executeQuery($conn, $query, $params);

    // Audit the viewing action
    insertAuditLog($conn, getCurrentUserId(), 'SELECT', 'audit_log', null, 
                  'Auditor viewed audit logs with filters: ' . 
                  "Action={$filterAction}, User={$filterUsername}, Table={$filterTable}");
        
    // Dropdown Filters
    $users = executeQuery($conn, "SELECT DISTINCT u.username as \"Username\" FROM audit_log a JOIN users u ON a.user_id = u.user_id ORDER BY u.username");
    $tables = executeQuery($conn, "SELECT DISTINCT table_affected as \"TableAffected\" FROM audit_log WHERE table_affected IS NOT NULL ORDER BY table_affected");
        
    closeDBConnection($conn);
}

include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-journal-text"></i> System Audit Logs</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item active">Audit Logs</li>
        </ol>
    </nav>
</div>

<!-- Filters -->
<div class="card mb-3">
    <div class="card-header">
        <i class="bi bi-funnel-fill"></i> Filter Logs
    </div>
    <div class="card-body">
        <form method="GET" action="" class="row g-3">
            <div class="col-md-2">
                <label for="action" class="form-label">Action</label>
                <select class="form-select form-select-sm" id="action" name="action">
                    <option value="">All Actions</option>
                    <option value="LOGIN" <?php echo ($filterAction === 'LOGIN') ? 'selected' : ''; ?>>LOGIN</option>
                    <option value="LOGOUT" <?php echo ($filterAction === 'LOGOUT') ? 'selected' : ''; ?>>LOGOUT</option>
                    <option value="INSERT" <?php echo ($filterAction === 'INSERT') ? 'selected' : ''; ?>>INSERT</option>
                    <option value="UPDATE" <?php echo ($filterAction === 'UPDATE') ? 'selected' : ''; ?>>UPDATE</option>
                    <option value="DELETE" <?php echo ($filterAction === 'DELETE') ? 'selected' : ''; ?>>DELETE</option>
                    <option value="SELECT" <?php echo ($filterAction === 'SELECT') ? 'selected' : ''; ?>>SELECT</option>
                </select>
            </div>
            
            <div class="col-md-2">
                <label for="user" class="form-label">User</label>
                <select class="form-select form-select-sm" id="user" name="user">
                    <option value="">All Users</option>
                    <?php foreach ($users as $user): ?>
                        <option value="<?php echo htmlspecialchars($user['Username']); ?>"
                            <?php echo ($filterUsername === $user['Username']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($user['Username']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-2">
                <label for="table" class="form-label">Table</label>
                <select class="form-select form-select-sm" id="table" name="table">
                    <option value="">All Tables</option>
                    <?php foreach ($tables as $table): ?>
                        <option value="<?php echo htmlspecialchars($table['TableAffected']); ?>"
                            <?php echo ($filterTable === $table['TableAffected']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($table['TableAffected']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-2">
                <label for="date_from" class="form-label">Date From</label>
                <input type="date" class="form-control form-control-sm" id="date_from" name="date_from" 
                       value="<?php echo htmlspecialchars($filterDateFrom); ?>">
            </div>
            
            <div class="col-md-2">
                <label for="date_to" class="form-label">Date To</label>
                <input type="date" class="form-control form-control-sm" id="date_to" name="date_to" 
                       value="<?php echo htmlspecialchars($filterDateTo); ?>">
            </div>
            
            <div class="col-12">
                <button type="submit" class="btn btn-primary btn-sm">
                    <i class="bi bi-search"></i> Apply Filters
                </button>
                <a href="view_audit_logs.php" class="btn btn-secondary btn-sm">
                    <i class="bi bi-x-circle"></i> Clear Filters
                </a>
                <a href="generate_report.php" class="btn btn-success btn-sm">
                    <i class="bi bi-file-earmark-bar-graph-fill"></i> Generate Report
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Audit Logs Table -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-table"></i> Audit Trail
        <span class="badge bg-info float-end"><?php echo count($auditLogs); ?> logs</span>
    </div>
    <div class="card-body">
        <?php if (!empty($auditLogs)): ?>
            <div class="table-responsive">
                <table class="table table-hover table-sm">
                    <thead class="table-dark">
                        <tr>
                            <th>Log ID</th>
                            <th>Timestamp</th>
                            <th>User</th>
                            <th>Action</th>
                            <th>Table</th>
                            <th>Record ID</th>
                            <th>IP Address</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($auditLogs as $log): ?>
                            <tr>
                                <td><small><?php echo $log['LogID']; ?></small></td>
                                <td>
                                    <small><?php echo date('Y-m-d H:i:s', strtotime($log['Timestamp'])); ?></small>
                                </td>
                                <td>
                                    <small><strong><?php echo htmlspecialchars($log['Username'] ?? 'System'); ?></strong></small>
                                </td>
                                <td>
                                    <?php
                                    $badgeClass = 'bg-secondary';
                                    if ($log['Action'] === 'LOGIN') $badgeClass = 'bg-success';
                                    if ($log['Action'] === 'INSERT') $badgeClass = 'bg-primary';
                                    if ($log['Action'] === 'UPDATE') $badgeClass = 'bg-info';
                                    if ($log['Action'] === 'DELETE') $badgeClass = 'bg-danger';
                                    if ($log['Action'] === 'SELECT') $badgeClass = 'bg-dark';
                                    ?>
                                    <span class="badge <?php echo $badgeClass; ?>">
                                        <?php echo htmlspecialchars($log['Action']); ?>
                                    </span>
                                </td>
                                <td>
                                    <small class="text-muted">
                                        <?php echo htmlspecialchars($log['TableAffected'] ?? 'N/A'); ?>
                                    </small>
                                </td>
                                <td><small><?php echo $log['RecordID'] ?? '-'; ?></small></td>
                                <td><small><code><?php echo htmlspecialchars($log['IPAddress'] ?? 'N/A'); ?></code></small></td>
                                <td>
                                    <small class="text-muted" title="<?php echo htmlspecialchars($log['Details'] ?? ''); ?>">
                                        <?php echo htmlspecialchars(substr($log['Details'] ?? '', 0, 50)); ?>
                                        <?php if (strlen($log['Details'] ?? '') > 50) echo '...'; ?>
                                    </small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                <i class="bi bi-exclamation-triangle-fill"></i> No audit logs found matching your criteria.
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>