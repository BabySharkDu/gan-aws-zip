<?php
/**
 * Auditor - Generate Compliance Report
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

requireRole('Auditor');
$pageTitle = 'Generate Report';

// Handle report generation
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $reportType = sanitizeInput($_GET['report_type'] ?? 'all');
    $dateFrom = sanitizeInput($_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days')));
    $dateTo = sanitizeInput($_GET['date_to'] ?? date('Y-m-d'));
    
    $conn = getDBConnection();
    
    if ($conn !== false) {
        // Build dynamic filter [cite: 9]
        $whereClauses = ["DATE(a.timestamp) BETWEEN ? AND ?"];
        $params = [$dateFrom, $dateTo];
        
        if ($reportType !== 'all') {
            $whereClauses[] = "a.action = ?";
            $params[] = $reportType;
        }
        
        $whereSQL = implode(' AND ', $whereClauses);
        
        $query = "SELECT a.log_id, a.timestamp, u.username, a.action, a.table_affected, 
                         a.record_id, a.ip_address, a.details
                  FROM audit_log a
                  LEFT JOIN users u ON a.user_id = u.user_id
                  WHERE $whereSQL
                  ORDER BY a.timestamp DESC";

        $results = executeQuery($conn, $query, $params);
        
        // Log the report generation event [cite: 13]
        insertAuditLog($conn, getCurrentUserId(), 'SELECT', 'audit_log', null, 
                       "Generated {$reportType} report from {$dateFrom} to {$dateTo}");
        
        // Always close connection before outputting a file 
        closeDBConnection($conn);
        
        // CSV Generation Logic (Remain unchanged)
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="audit_report_' . date('Y-m-d_His') . '.csv"');
        $output = fopen('php://output', 'w');
        fputcsv($output, array('Log ID', 'Timestamp', 'Username', 'Action', 'Table', 'Record ID', 'IP Address', 'Details'));
        
        foreach ($results as $row) {
            fputcsv($output, $row);
        }
        fclose($output);
        exit();
    }
}

// Statistics Overview logic 
$conn = getDBConnection();
$stats = array('total_logs' => 0, 'total_logins' => 0, 'total_modifications' => 0, 'unique_users' => 0);

if ($conn !== false) {
    $statsQuery = "SELECT 
        COUNT(*) as total_logs,
        COUNT(*) FILTER (WHERE action = 'LOGIN') as total_logins,
        COUNT(*) FILTER (WHERE action IN ('INSERT','UPDATE','DELETE')) as total_modifications,
        COUNT(DISTINCT user_id) as unique_users
        FROM audit_log";
    
    $res = executeQuery($conn, $statsQuery);
    if ($res) {
        $stats = [
            'total_logs' => $res[0]['total_logs'],
            'total_logins' => $res[0]['total_logins'],
            'total_modifications' => $res[0]['total_modifications'],
            'unique_users' => $res[0]['unique_users']
        ];
    }
    closeDBConnection($conn);
}

include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-file-earmark-bar-graph-fill"></i> Generate Compliance Report</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item active">Generate Report</li>
        </ol>
    </nav>
</div>

<!-- Statistics Overview -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <h6 class="text-uppercase mb-0">Total Logs</h6>
                <h2 class="mb-0"><?php echo number_format($stats['total_logs']); ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-success">
            <div class="card-body">
                <h6 class="text-uppercase mb-0">Login Events</h6>
                <h2 class="mb-0"><?php echo number_format($stats['total_logins']); ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <h6 class="text-uppercase mb-0">Data Changes</h6>
                <h2 class="mb-0"><?php echo number_format($stats['total_modifications']); ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-info">
            <div class="card-body">
                <h6 class="text-uppercase mb-0">Active Users</h6>
                <h2 class="mb-0"><?php echo $stats['unique_users']; ?></h2>
            </div>
        </div>
    </div>
</div>

<!-- Report Generation Form -->
<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-gear-fill"></i> Report Configuration
            </div>
            <div class="card-body">
                <form method="GET" action="" id="reportForm">
                    <input type="hidden" name="export" value="csv">
                    
                    <div class="mb-3">
                        <label for="report_type" class="form-label">
                            <i class="bi bi-filter"></i> Report Type
                        </label>
                        <select class="form-select" id="report_type" name="report_type" required>
                            <option value="all">All Activities</option>
                            <option value="LOGIN">Login History</option>
                            <option value="LOGOUT">Logout History</option>
                            <option value="INSERT">Data Insertions</option>
                            <option value="UPDATE">Data Updates</option>
                            <option value="DELETE">Data Deletions</option>
                            <option value="SELECT">Data Access (SELECT)</option>
                        </select>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="date_from" class="form-label">
                                <i class="bi bi-calendar-event"></i> Date From
                            </label>
                            <input type="date" class="form-control" id="date_from" name="date_from" 
                                   value="<?php echo date('Y-m-d', strtotime('-30 days')); ?>" required>
                        </div>
                        
                        <div class="col-md-6">
                            <label for="date_to" class="form-label">
                                <i class="bi bi-calendar-event-fill"></i> Date To
                            </label>
                            <input type="date" class="form-control" id="date_to" name="date_to" 
                                   value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle-fill"></i> <strong>Report Format:</strong> CSV (Comma Separated Values)
                        <br>
                        <small>The generated report can be opened in Microsoft Excel, Google Sheets, or any spreadsheet application.</small>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-success btn-lg">
                            <i class="bi bi-download"></i> Generate & Download Report
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Report Templates -->
        <div class="card mt-3">
            <div class="card-header">
                <i class="bi bi-bookmark-fill"></i> Quick Report Templates
            </div>
            <div class="card-body">
                <div class="list-group">
                    <a href="?export=csv&report_type=LOGIN&date_from=<?php echo date('Y-m-d'); ?>&date_to=<?php echo date('Y-m-d'); ?>" 
                       class="list-group-item list-group-item-action">
                        <i class="bi bi-box-arrow-in-right text-success"></i> 
                        <strong>Today's Login Report</strong>
                        <br>
                        <small class="text-muted">All login activities for today</small>
                    </a>
                    
                    <a href="?export=csv&report_type=all&date_from=<?php echo date('Y-m-d', strtotime('-7 days')); ?>&date_to=<?php echo date('Y-m-d'); ?>" 
                       class="list-group-item list-group-item-action">
                        <i class="bi bi-calendar-week text-primary"></i> 
                        <strong>Weekly Activity Report</strong>
                        <br>
                        <small class="text-muted">All activities for the past 7 days</small>
                    </a>
                    
                    <a href="?export=csv&report_type=DELETE&date_from=<?php echo date('Y-m-d', strtotime('-30 days')); ?>&date_to=<?php echo date('Y-m-d'); ?>" 
                       class="list-group-item list-group-item-action">
                        <i class="bi bi-trash-fill text-danger"></i> 
                        <strong>Deletion Report (30 Days)</strong>
                        <br>
                        <small class="text-muted">All delete operations in the past month</small>
                    </a>
                    
                    <a href="?export=csv&report_type=all&date_from=<?php echo date('Y-m-01'); ?>&date_to=<?php echo date('Y-m-d'); ?>" 
                       class="list-group-item list-group-item-action">
                        <i class="bi bi-calendar-month text-info"></i> 
                        <strong>Monthly Compliance Report</strong>
                        <br>
                        <small class="text-muted">All activities for current month</small>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Compliance Notice -->
        <div class="alert alert-warning mt-3">
            <i class="bi bi-shield-exclamation"></i> <strong>PDPA 2010 Compliance Notice:</strong>
            <ul class="mb-0 mt-2">
                <li>All report generation activities are logged</li>
                <li>Reports contain personal data and must be handled securely</li>
                <li>Do not share reports with unauthorized personnel</li>
                <li>Store reports in encrypted storage</li>
                <li>Delete reports after retention period expires</li>
            </ul>
        </div>
    </div>
</div>

<script>
// Validate date range
document.getElementById('reportForm').addEventListener('submit', function(e) {
    const dateFrom = new Date(document.getElementById('date_from').value);
    const dateTo = new Date(document.getElementById('date_to').value);
    
    if (dateFrom > dateTo) {
        alert('Date From cannot be after Date To');
        e.preventDefault();
        return false;
    }
    
    // Show loading message
    const submitBtn = this.querySelector('button[type="submit"]');
    submitBtn.innerHTML = '<i class="spinner-border spinner-border-sm"></i> Generating Report...';
    submitBtn.disabled = true;
});
</script>

<?php include '../includes/footer.php'; ?>