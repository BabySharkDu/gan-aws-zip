<?php
/**
 * Auditor Dashboard
 * Security audit and compliance overview
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

// Require Auditor role
requireRole('Auditor');
$pageTitle = 'Auditor Dashboard';

// Get database connection
$conn = getDBConnection();

// Get statistics
$stats = array(
    'total_logs' => 0,
    'today_logs' => 0,
    'login_attempts' => 0,
    'data_modifications' => 0
);

$recentActivities = array();
$actionBreakdown = array();

if ($conn !== false) {
    $statsQuery = "SELECT 
        COUNT(*) as total_logs,
        COUNT(*) FILTER (WHERE DATE(timestamp) = CURRENT_DATE) as today_logs,
        COUNT(*) FILTER (WHERE action = 'LOGIN' AND DATE(timestamp) = CURRENT_DATE) as login_attempts,
        COUNT(*) FILTER (WHERE action IN ('INSERT','UPDATE','DELETE') AND DATE(timestamp) = CURRENT_DATE) as data_modifications
        FROM audit_log";
    
    $statsResult = executeQuery($conn, $statsQuery);
    if ($statsResult) {
        $stats = [
            'total_logs' => $statsResult[0]['total_logs'] ?? 0,
            'today_logs' => $statsResult[0]['today_logs'] ?? 0,
            'login_attempts' => $statsResult[0]['login_attempts'] ?? 0,
            'data_modifications' => $statsResult[0]['data_modifications'] ?? 0
        ];
    }

    $recentQuery = "SELECT a.timestamp as \"Timestamp\", u.username as \"Username\", 
                           a.action as \"Action\", a.table_affected as \"TableAffected\", 
                           a.ip_address as \"IPAddress\"
                    FROM audit_log a
                    LEFT JOIN users u ON a.user_id = u.user_id
                    ORDER BY a.timestamp DESC
                    LIMIT 15";
    $recentActivities = executeQuery($conn, $recentQuery);
    
    $breakdownQuery = "SELECT action as \"Action\", COUNT(*) as \"Count\"
                       FROM audit_log
                       WHERE timestamp >= CURRENT_DATE - INTERVAL '7 days'
                       GROUP BY action
                       ORDER BY \"Count\" DESC";
    $actionBreakdown = executeQuery($conn, $breakdownQuery);
    
    closeDBConnection($conn);
}

include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-shield-check"></i> Auditor Dashboard</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </nav>
</div>

<!-- Statistics Cards -->
<div class="row">
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">Total Logs</h6>
                        <h2 class="mb-0"><?php echo number_format($stats['total_logs']); ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-journal-text" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <a href="view_audit_logs.php" class="text-white text-decoration-none">
                    View all logs <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-success">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">Today's Logs</h6>
                        <h2 class="mb-0"><?php echo $stats['today_logs']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-calendar-check-fill" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <span class="text-white"><?php echo date('d M Y'); ?></span>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-info">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">Login Attempts</h6>
                        <h2 class="mb-0"><?php echo $stats['login_attempts']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-box-arrow-in-right" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <span class="text-white">Today</span>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">Modifications</h6>
                        <h2 class="mb-0"><?php echo $stats['data_modifications']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-pencil-square" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <span class="text-white">INSERT/UPDATE/DELETE</span>
            </div>
        </div>
    </div>
</div>

<!-- Recent Activities and Action Breakdown -->
<div class="row">
    <!-- Recent Activities -->
    <div class="col-md-8 mb-4">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-activity"></i> Recent System Activities
            </div>
            <div class="card-body">
                <?php if (!empty($recentActivities)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover table-sm">
                            <thead>
                                <tr>
                                    <th>Time</th>
                                    <th>User</th>
                                    <th>Action</th>
                                    <th>Table</th>
                                    <th>IP Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentActivities as $activity): ?>
                                    <tr>
                                        <td>
                                            <small><?php echo date('H:i:s', strtotime($activity['Timestamp'])); ?></small>
                                        </td>
                                        <td>
                                            <small><?php echo htmlspecialchars($activity['Username'] ?? 'System'); ?></small>
                                        </td>
                                        <td>
                                            <?php
                                            $badgeClass = 'bg-secondary';
                                            if ($activity['Action'] === 'LOGIN') $badgeClass = 'bg-success';
                                            if ($activity['Action'] === 'INSERT') $badgeClass = 'bg-primary';
                                            if ($activity['Action'] === 'UPDATE') $badgeClass = 'bg-info';
                                            if ($activity['Action'] === 'DELETE') $badgeClass = 'bg-danger';
                                            if ($activity['Action'] === 'SELECT') $badgeClass = 'bg-dark';
                                            ?>
                                            <span class="badge <?php echo $badgeClass; ?>">
                                                <?php echo htmlspecialchars($activity['Action']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?php echo htmlspecialchars($activity['TableAffected'] ?? 'N/A'); ?>
                                            </small>
                                        </td>
                                        <td>
                                            <small><code><?php echo htmlspecialchars($activity['IPAddress'] ?? 'N/A'); ?></code></small>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No recent activities</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Action Breakdown -->
    <div class="col-md-4 mb-4">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-pie-chart-fill"></i> Action Breakdown (7 Days)
            </div>
            <div class="card-body">
                <?php if (!empty($actionBreakdown)): ?>
                    <ul class="list-group list-group-flush">
                        <?php foreach ($actionBreakdown as $action): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php
                                $badgeClass = 'bg-secondary';
                                if ($action['Action'] === 'LOGIN') $badgeClass = 'bg-success';
                                if ($action['Action'] === 'INSERT') $badgeClass = 'bg-primary';
                                if ($action['Action'] === 'UPDATE') $badgeClass = 'bg-info';
                                if ($action['Action'] === 'DELETE') $badgeClass = 'bg-danger';
                                if ($action['Action'] === 'SELECT') $badgeClass = 'bg-dark';
                                ?>
                                <span class="badge <?php echo $badgeClass; ?>">
                                    <?php echo htmlspecialchars($action['Action']); ?>
                                </span>
                                <span class="badge bg-light text-dark">
                                    <?php echo number_format($action['Count']); ?>
                                </span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="text-muted">No data available</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-lightning-fill"></i> Quick Actions
    </div>
    <div class="card-body">
        <div class="d-grid gap-2 d-md-flex">
            <a href="view_audit_logs.php" class="btn btn-primary btn-lg">
                <i class="bi bi-journal-text"></i> View All Audit Logs
            </a>
            <a href="view_audit_logs.php?action=LOGIN" class="btn btn-success btn-lg">
                <i class="bi bi-box-arrow-in-right"></i> View Login History
            </a>
            <a href="view_audit_logs.php?action=DELETE" class="btn btn-danger btn-lg">
                <i class="bi bi-trash-fill"></i> View Deletions
            </a>
        </div>
    </div>
</div>

<!-- Access Notice -->
<div class="alert alert-info mt-3">
    <i class="bi bi-info-circle-fill"></i> <strong>Auditor Access:</strong> 
    You have read-only access to audit logs. You cannot modify any data or access patient medical information. 
    All audit log views are also logged for compliance purposes.
</div>

<?php
include '../includes/footer.php';
?>