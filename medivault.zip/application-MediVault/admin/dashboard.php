<?php
/**
 * Administrator Dashboard - PostgreSQL Version
 * System overview and statistics
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

requireRole('Administrator');
$pageTitle = 'Administrator Dashboard';

$conn = getDBConnection();

// Initialize stats
$stats = [
    'total_users' => 0,
    'total_patients' => 0,
    'total_records' => 0,
    'recent_logins' => 0
];

if ($conn !== false) {
    // Get total users
    $result = executeQuery($conn, "SELECT COUNT(*) as count FROM users");
    $stats['total_users'] = $result[0]['count'] ?? 0;
    
    // Get total patients
    $result = executeQuery($conn, "SELECT COUNT(*) as count FROM patients");
    $stats['total_patients'] = $result[0]['count'] ?? 0;
    
    // Get total medical records
    $result = executeQuery($conn, "SELECT COUNT(*) as count FROM medical_records");
    $stats['total_records'] = $result[0]['count'] ?? 0;
    
    // Get recent logins (last 24 hours)
    $query = "SELECT COUNT(DISTINCT user_id) as count 
              FROM audit_log 
              WHERE action = 'LOGIN' 
              AND timestamp >= CURRENT_TIMESTAMP - INTERVAL '24 hours'";
    $result = executeQuery($conn, $query);
    $stats['recent_logins'] = $result[0]['count'] ?? 0;
    
    // Get recent users
    $query = "SELECT u.user_id, u.username, r.role_name, u.created_date
              FROM users u
              INNER JOIN roles r ON u.role_id = r.role_id
              WHERE u.is_active = true
              ORDER BY u.created_date DESC
              LIMIT 5";
    $recentUsers = executeQuery($conn, $query);
    
    // Get recent activities
    $query = "SELECT a.log_id, a.user_id, u.username, a.action, a.table_affected, a.timestamp
              FROM audit_log a
              LEFT JOIN users u ON a.user_id = u.user_id
              ORDER BY a.timestamp DESC
              LIMIT 10";
    $recentActivities = executeQuery($conn, $query);
    
    // Log dashboard view
    insertAuditLog($conn, getCurrentUserId(), 'SELECT', 'dashboard', null, 'Admin viewed dashboard');
}

include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-speedometer2"></i> Administrator Dashboard</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </nav>
</div>

<!-- Statistics Cards -->
<div class="row">
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">Total Users</h6>
                        <h2 class="mb-0"><?php echo $stats['total_users']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-people-fill" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <a href="manage_users.php" class="text-white text-decoration-none">
                    View all users <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-success">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">Total Patients</h6>
                        <h2 class="mb-0"><?php echo $stats['total_patients']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-person-lines-fill" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <span class="text-white">Registered patients</span>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-info">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">Medical Records</h6>
                        <h2 class="mb-0"><?php echo $stats['total_records']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-file-earmark-medical-fill" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <span class="text-white">Total records</span>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">Recent Logins</h6>
                        <h2 class="mb-0"><?php echo $stats['recent_logins']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-box-arrow-in-right" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <span class="text-white">Last 24 hours</span>
            </div>
        </div>
    </div>
</div>

<!-- Recent Users and Activities -->
<div class="row">
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-person-plus-fill"></i> Recent Users
            </div>
            <div class="card-body">
                <?php if (!empty($recentUsers)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Role</th>
                                    <th>Created</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentUsers as $user): ?>
                                    <tr>
                                        <td>
                                            <i class="bi bi-person-circle"></i> 
                                            <?php echo htmlspecialchars($user['username']); ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-secondary">
                                                <?php echo htmlspecialchars($user['role_name']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <small><?php echo date('M d, Y', strtotime($user['created_date'])); ?></small>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No recent users</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-activity"></i> Recent Activities
            </div>
            <div class="card-body">
                <?php if (!empty($recentActivities)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover table-sm">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Action</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentActivities as $activity): ?>
                                    <tr>
                                        <td>
                                            <small><?php echo htmlspecialchars($activity['username'] ?? 'System'); ?></small>
                                        </td>
                                        <td>
                                            <?php
                                            $badgeClass = 'bg-secondary';
                                            if ($activity['action'] === 'LOGIN') $badgeClass = 'bg-success';
                                            if ($activity['action'] === 'INSERT') $badgeClass = 'bg-primary';
                                            if ($activity['action'] === 'DELETE') $badgeClass = 'bg-danger';
                                            ?>
                                            <span class="badge <?php echo $badgeClass; ?>">
                                                <?php echo htmlspecialchars($activity['action']); ?>
                                            </span>
                                            <small class="text-muted">
                                                <?php echo htmlspecialchars($activity['table_affected']); ?>
                                            </small>
                                        </td>
                                        <td>
                                            <small><?php echo date('H:i', strtotime($activity['timestamp'])); ?></small>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <a href="system_logs.php" class="btn btn-sm btn-outline-primary">
                        View all logs <i class="bi bi-arrow-right"></i>
                    </a>
                <?php else: ?>
                    <p class="text-muted">No recent activities</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-lightning-fill"></i> Quick Actions
    </div>
    <div class="card-body">
        <div class="d-grid gap-2 d-md-flex">
            <a href="add_user.php" class="btn btn-primary">
                <i class="bi bi-person-plus-fill"></i> Add New User
            </a>
            <a href="manage_users.php" class="btn btn-success">
                <i class="bi bi-people-fill"></i> Manage Users
            </a>
            <a href="system_logs.php" class="btn btn-info text-white">
                <i class="bi bi-file-text-fill"></i> View System Logs
            </a>
        </div>
    </div>
</div>

<?php
closeDBConnection($conn);
include '../includes/footer.php';
?>