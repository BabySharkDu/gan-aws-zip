<?php
/**
 * Admin - Manage Users - PostgreSQL Version
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

requireRole('Administrator');
$pageTitle = 'Manage Users';

// Handle deactivate action
if (isset($_GET['delete']) && isset($_GET['id'])) {
    $userId = (int)$_GET['id'];
    $conn = getDBConnection();
    
    if ($conn !== false) {
        $query = "UPDATE users SET is_active = false WHERE user_id = ?";
        $result = executeNonQuery($conn, $query, [$userId]);

        if ($result !== false && $result > 0) {
            insertAuditLog($conn, getCurrentUserId(), 'UPDATE', 'users', $userId, 
                        'Admin deactivated user');
            showSuccess('User deactivated successfully');
        } else {
            showError('Failed to deactivate user');
        }
        
        closeDBConnection($conn);
    }
    redirect('manage_users.php');
}

// Handle reactivate action
if (isset($_GET['reactivate']) && isset($_GET['id'])) {
    $userId = (int)$_GET['id'];
    $conn = getDBConnection();
    
    if ($conn !== false) {
        $query = "UPDATE users SET is_active = true, failed_login_attempts = 0 WHERE user_id = ?";
        $result = executeNonQuery($conn, $query, [$userId]);

        if ($result !== false && $result > 0) {
            insertAuditLog($conn, getCurrentUserId(), 'UPDATE', 'users', $userId, 
                        'Admin reactivated user');
            showSuccess('User reactivated successfully');
        } else {
            showError('Failed to reactivate user');
        }
        
        closeDBConnection($conn);
    }
    redirect('manage_users.php');
}

$conn = getDBConnection();
$users = [];

if ($conn !== false) {
    $query = "SELECT u.user_id, u.username, u.email, u.is_active, u.last_login, u.created_date,
                     r.role_name
              FROM users u
              INNER JOIN roles r ON u.role_id = r.role_id
              ORDER BY u.created_date DESC";
    $users = executeQuery($conn, $query);

    insertAuditLog($conn, getCurrentUserId(), 'SELECT', 'users', null, 'Admin viewed user list');
    closeDBConnection($conn);
}

include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-people-fill"></i> Manage Users</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item active">Manage Users</li>
        </ol>
    </nav>
</div>

<div class="card mb-3">
    <div class="card-body">
        <a href="add_user.php" class="btn btn-success">
            <i class="bi bi-person-plus-fill"></i> Add New User
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <i class="bi bi-table"></i> User List
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-primary">
                    <tr>
                        <th>User ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Last Login</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $user['user_id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($user['username']); ?></strong></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <span class="badge bg-secondary">
                                    <?php echo htmlspecialchars($user['role_name']); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($user['is_active']): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <small><?php echo $user['last_login'] ? date('d M Y H:i', strtotime($user['last_login'])) : 'Never'; ?></small>
                            </td>
                            <td>
                                <small><?php echo date('d M Y', strtotime($user['created_date'])); ?></small>
                            </td>
                            <td>
                                <?php if ($user['user_id'] != getCurrentUserId()): ?>
                                    <?php if ($user['is_active']): ?>
                                        <a href="?delete=1&id=<?php echo $user['user_id']; ?>" 
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Deactivate this user?')">
                                            <i class="bi bi-x-circle"></i> Deactivate
                                        </a>
                                    <?php else: ?>
                                        <a href="?reactivate=1&id=<?php echo $user['user_id']; ?>" 
                                           class="btn btn-sm btn-success"
                                           onclick="return confirm('Reactivate this user?')">
                                            <i class="bi bi-check-circle-fill"></i> Reactivate
                                        </a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">Current User</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>