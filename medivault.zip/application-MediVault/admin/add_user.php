<?php
/**
 * Administrator - Add User
 * SECURE VERSION: Uses stored procedures only
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

requireRole('Administrator');
$pageTitle = 'Add User';

$errors = array();
$conn = getDBConnection();
$roles = array();

if ($conn !== false) {
    $query = "SELECT role_id, role_name FROM roles ORDER BY role_id";
    $roles = executeQuery($conn, $query);
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $errors[] = 'Invalid security token. Please refresh the page.';
    } else {
        $username = sanitizeInput($_POST['username'] ?? '');
        $email = sanitizeInput($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        $roleId = (int)($_POST['role_id'] ?? 0);
        
        // Validation [cite: 6, 25]
        if (empty($username)) $errors[] = 'Username is required';
        if (empty($email)) $errors[] = 'Email is required';
        if (empty($password)) $errors[] = 'Password is required';
        if ($password !== $confirmPassword) $errors[] = 'Passwords do not match';
        if (strlen($password) < 8) $errors[] = 'Password must be at least 8 characters';
        if ($roleId === 0) $errors[] = 'Please select a role';
        
        if (empty($errors) && $conn !== false) {
            // Check if username exists using direct query [cite: 6]
            $checkQuery = "SELECT COUNT(*) as count FROM users WHERE username = ?";
            $checkResult = executeQuery($conn, $checkQuery, [$username]);
            
            if ($checkResult[0]['count'] > 0) {
                $errors[] = 'Username already exists';
            } else {
                // Hash password and insert [cite: 6, 25]
                $passwordHash = hashPassword($password);
                $createQuery = "INSERT INTO users (username, password_hash, role_id, email, created_by) 
                               VALUES (?, ?, ?, ?, ?) RETURNING user_id";
                
                $stmt = $conn->prepare($createQuery);
                $success = $stmt->execute([$username, $passwordHash, $roleId, $email, getCurrentUserId()]);
                
                if ($success) {
                    $newUserId = $stmt->fetch()['user_id'];
                    
                    // Maintain Application-level Audit Log [cite: 13]
                    insertAuditLog($conn, getCurrentUserId(), 'INSERT', 'users', $newUserId, 
                                  "Admin created new user: {$username}");
                    
                    showSuccess("User created successfully!");
                    
                    // Close connection before redirecting
                    closeDBConnection($conn);
                    redirect('admin/manage_users.php');
                } else {
                    $errors[] = 'Failed to create user.';
                }
            }
        }
    }
}

$csrfToken = generateCSRFToken();

// Always close the connection at the end of the logic block 
if ($conn !== false) {
    closeDBConnection($conn);
}

include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-person-plus-fill"></i> Add New User</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="manage_users.php">Manage Users</a></li>
            <li class="breadcrumb-item active">Add User</li>
        </ol>
    </nav>
</div>

<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-clipboard-plus"></i> User Registration Form
            </div>
            <div class="card-body">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">Username <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="username" name="username" 
                               value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="role_id" class="form-label">Role <span class="text-danger">*</span></label>
                        <select class="form-select" id="role_id" name="role_id" required>
                            <option value="">Select Role</option>
                            <?php foreach ($roles as $role): ?>
                                <option value="<?php echo $role['RoleID']; ?>">
                                    <?php echo htmlspecialchars($role['RoleName']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Password <span class="text-danger">*</span></label>
                        <input type="password" class="form-control" id="password" name="password" 
                               minlength="8" required>
                        <small class="text-muted">Minimum 8 characters</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password <span class="text-danger">*</span></label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                               minlength="8" required>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-circle-fill"></i> Create User
                        </button>
                        <a href="manage_users.php" class="btn btn-secondary">
                            <i class="bi bi-x-circle"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Security Notice -->
        <div class="alert alert-info mt-3">
            <i class="bi bi-shield-check"></i> <strong>Security:</strong> 
            All operations use stored procedures. Direct database table access is prohibited.
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>