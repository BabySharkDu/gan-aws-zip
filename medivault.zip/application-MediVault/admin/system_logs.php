<?php
/**
 * Administrator - System Logs
 * CONVERTED: Uses direct PostgreSQL queries instead of stored procedures
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

requireRole('Administrator');
$pageTitle = 'System Logs';

$filterAction = sanitizeInput($_GET['action'] ?? '');
$filterUsername = sanitizeInput($_GET['user'] ?? '');
$filterTable = sanitizeInput($_GET['table'] ?? '');
$dateFrom = sanitizeInput($_GET['date_from'] ?? '');
$dateTo = sanitizeInput($_GET['date_to'] ?? '');
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 100;

$conn = getDBConnection();
$auditLogs = array();
$users = array();
$tables = array();
$stats = array(
    'total_today' => 0,
    'failed_logins' => 0,
    'data_changes' => 0
);

if ($conn !== false) {
    // Get audit statistics using direct query
    $statsQuery = "SELECT 
        COUNT(*) FILTER (WHERE DATE(timestamp) = CURRENT_DATE) as total_today,
        COUNT(*) FILTER (WHERE action = 'LOGIN_FAILED' AND DATE(timestamp) = CURRENT_DATE) as failed_logins,
        COUNT(*) FILTER (WHERE action IN ('INSERT','UPDATE','DELETE') AND DATE(timestamp) = CURRENT_DATE) as data_changes
        FROM audit_log";
    
    $result = executeQuery($conn, $statsQuery);
    if ($result && count($result) > 0) {
        $stats['total_today'] = $result[0]['total_today'] ?? 0;
        $stats['failed_logins'] = $result[0]['failed_logins'] ?? 0;
        $stats['data_changes'] = $result[0]['data_changes'] ?? 0;
    }

    // Build WHERE clause dynamically for filtering
    $whereClauses = [];
    $params = [];
    
    if (!empty($filterAction)) {
        $whereClauses[] = "a.action = ?";
        $params[] = $filterAction;
    }
    
    if (!empty($filterUsername)) {
        $whereClauses[] = "u.username = ?";
        $params[] = $filterUsername;
    }
    
    if (!empty($filterTable)) {
        $whereClauses[] = "a.table_affected = ?";
        $params[] = $filterTable;
    }
    
    if (!empty($dateFrom)) {
        $whereClauses[] = "DATE(a.timestamp) >= ?";
        $params[] = $dateFrom;
    }
    
    if (!empty($dateTo)) {
        $whereClauses[] = "DATE(a.timestamp) <= ?";
        $params[] = $dateTo;
    }
    
    $whereSQL = !empty($whereClauses) ? 'WHERE ' . implode(' AND ', $whereClauses) : '';

    // Get audit logs with username
    $query = "SELECT a.log_id, a.user_id, u.username, a.action, a.table_affected, 
                     a.record_id, a.timestamp, a.ip_address, a.session_id, a.details
              FROM audit_log a
              LEFT JOIN users u ON a.user_id = u.user_id
              $whereSQL
              ORDER BY a.timestamp DESC
              LIMIT ?";
    
    $params[] = $limit;
    $auditLogs = executeQuery($conn, $query, $params);

    insertAuditLog($conn, getCurrentUserId(), 'SELECT', 'audit_log', null, 
                'Admin viewed system logs with filters: ' .
                "Action={$filterAction}, User={$filterUsername}, Table={$filterTable}");

    // Get distinct users for filter dropdown
    $userQuery = "SELECT DISTINCT u.username 
                  FROM audit_log a
                  LEFT JOIN users u ON a.user_id = u.user_id
                  WHERE u.username IS NOT NULL
                  ORDER BY u.username";
    $users = executeQuery($conn, $userQuery);

    // Get distinct tables for filter dropdown
    $tableQuery = "SELECT DISTINCT table_affected 
                   FROM audit_log 
                   WHERE table_affected IS NOT NULL 
                   ORDER BY table_affected";
    $tables = executeQuery($conn, $tableQuery);
    
    closeDBConnection($conn);
}

include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-file-text-fill"></i> System Audit Logs</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item active">System Logs</li>
        </ol>
    </nav>
</div>

<!-- Statistics Cards -->
<div class="row mb-3">
    <div class="col-md-3">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <h6 class="text-uppercase mb-0">Today's Logs</h6>
                <h2 class="mb-0"><?php echo $stats['total_today']; ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-danger">
            <div class="card-body">
                <h6 class="text-uppercase mb-0">Failed Logins</h6>
                <h2 class="mb-0"><?php echo $stats['failed_logins']; ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <h6 class="text-uppercase mb-0">Data Changes</h6>
                <h2 class="mb-0"><?php echo $stats['data_changes']; ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-info">
            <div class="card-body">
                <h6 class="text-uppercase mb-0">Showing</h6>
                <h2 class="mb-0"><?php echo count($auditLogs); ?></h2>
            </div>
        </div>
    </div>
</div>

<!-- Advanced Filters -->
<div class="card mb-3">
    <div class="card-header">
        <i class="bi bi-funnel-fill"></i> Advanced Filters
    </div>
    <div class="card-body">
        <form method="GET" action="" class="row g-3">
            <div class="col-md-2">
                <label for="action" class="form-label">Action</label>
                <select class="form-select form-select-sm" id="action" name="action">
                    <option value="">All Actions</option>
                    <option value="LOGIN" <?php echo ($filterAction === 'LOGIN') ? 'selected' : ''; ?>>LOGIN</option>
                    <option value="LOGOUT" <?php echo ($filterAction === 'LOGOUT') ? 'selected' : ''; ?>>LOGOUT</option>
                    <option value="INSERT" <?php echo ($filterAction === 'INSERT') ? 'selected' : ''; ?>>INSERT</option>
                    <option value="UPDATE" <?php echo ($filterAction === 'UPDATE') ? 'selected' : ''; ?>>UPDATE</option>
                    <option value="DELETE" <?php echo ($filterAction === 'DELETE') ? 'selected' : ''; ?>>DELETE</option>
                    <option value="SELECT" <?php echo ($filterAction === 'SELECT') ? 'selected' : ''; ?>>SELECT</option>
                </select>
            </div>
            
            <div class="col-md-2">
                <label for="user" class="form-label">User</label>
                <select class="form-select form-select-sm" id="user" name="user">
                    <option value="">All Users</option>
                    <?php foreach ($users as $user): ?>
                        <option value="<?php echo htmlspecialchars($user['username']); ?>"
                            <?php echo ($filterUsername === $user['username']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($user['username']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-2">
                <label for="table" class="form-label">Table</label>
                <select class="form-select form-select-sm" id="table" name="table">
                    <option value="">All Tables</option>
                    <?php foreach ($tables as $table): ?>
                        <option value="<?php echo htmlspecialchars($table['table_affected']); ?>"
                            <?php echo ($filterTable === $table['table_affected']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($table['table_affected']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-2">
                <label for="date_from" class="form-label">Date From</label>
                <input type="date" class="form-control form-control-sm" id="date_from" name="date_from" 
                       value="<?php echo htmlspecialchars($dateFrom); ?>">
            </div>
            
            <div class="col-md-2">
                <label for="date_to" class="form-label">Date To</label>
                <input type="date" class="form-control form-control-sm" id="date_to" name="date_to" 
                       value="<?php echo htmlspecialchars($dateTo); ?>">
            </div>
            
            <div class="col-md-2">
                <label for="limit" class="form-label">Limit</label>
                <select class="form-select form-select-sm" id="limit" name="limit">
                    <option value="50" <?php echo ($limit === 50) ? 'selected' : ''; ?>>50</option>
                    <option value="100" <?php echo ($limit === 100) ? 'selected' : ''; ?>>100</option>
                    <option value="500" <?php echo ($limit === 500) ? 'selected' : ''; ?>>500</option>
                    <option value="1000" <?php echo ($limit === 1000) ? 'selected' : ''; ?>>1000</option>
                </select>
            </div>
            
            <div class="col-12">
                <button type="submit" class="btn btn-primary btn-sm">
                    <i class="bi bi-search"></i> Apply Filters
                </button>
                <a href="system_logs.php" class="btn btn-secondary btn-sm">
                    <i class="bi bi-x-circle"></i> Clear Filters
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Audit Logs Table -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-table"></i> System Audit Trail
        <span class="badge bg-info float-end"><?php echo count($auditLogs); ?> records</span>
    </div>
    <div class="card-body">
        <?php if (!empty($auditLogs)): ?>
            <div class="table-responsive">
                <table class="table table-hover table-sm">
                    <thead class="table-dark">
                        <tr>
                            <th>Log ID</th>
                            <th>Timestamp</th>
                            <th>User ID</th>
                            <th>Username</th>
                            <th>Action</th>
                            <th>Table</th>
                            <th>Record ID</th>
                            <th>IP Address</th>
                            <th>Session ID</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($auditLogs as $log): ?>
                            <tr>
                                <td><small><?php echo $log['log_id']; ?></small></td>
                                <td>
                                    <small><?php echo date('Y-m-d H:i:s', strtotime($log['timestamp'])); ?></small>
                                </td>
                                <td><small><?php echo $log['user_id'] ?? '-'; ?></small></td>
                                <td>
                                    <small><strong><?php echo htmlspecialchars($log['username'] ?? 'System'); ?></strong></small>
                                </td>
                                <td>
                                    <?php
                                    $badgeClass = 'bg-secondary';
                                    if ($log['action'] === 'LOGIN') $badgeClass = 'bg-success';
                                    if ($log['action'] === 'LOGOUT') $badgeClass = 'bg-info';
                                    if ($log['action'] === 'INSERT') $badgeClass = 'bg-primary';
                                    if ($log['action'] === 'UPDATE') $badgeClass = 'bg-warning';
                                    if ($log['action'] === 'DELETE') $badgeClass = 'bg-danger';
                                    if ($log['action'] === 'SELECT') $badgeClass = 'bg-dark';
                                    ?>
                                    <span class="badge <?php echo $badgeClass; ?>">
                                        <?php echo htmlspecialchars($log['action']); ?>
                                    </span>
                                </td>
                                <td>
                                    <small class="text-muted">
                                        <?php echo htmlspecialchars($log['table_affected'] ?? 'N/A'); ?>
                                    </small>
                                </td>
                                <td><small><?php echo $log['record_id'] ?? '-'; ?></small></td>
                                <td><small><code><?php echo htmlspecialchars($log['ip_address'] ?? 'N/A'); ?></code></small></td>
                                <td><small><code><?php echo htmlspecialchars(substr($log['session_id'] ?? '', 0, 10)); ?>...</code></small></td>
                                <td>
                                    <small class="text-muted" title="<?php echo htmlspecialchars($log['details'] ?? ''); ?>">
                                        <?php echo htmlspecialchars(substr($log['details'] ?? '', 0, 30)); ?>
                                        <?php if (strlen($log['details'] ?? '') > 30) echo '...'; ?>
                                    </small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                <i class="bi bi-exclamation-triangle-fill"></i> No audit logs found matching your criteria.
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Security Notice -->
<div class="alert alert-warning mt-3">
    <i class="bi bi-shield-exclamation"></i> <strong>Administrator Notice:</strong> 
    All audit log views are tracked. Unauthorized access or tampering with audit logs is a serious security violation.
</div>

<?php include '../includes/footer.php'; ?>