<?php
/**
 * MediVault - Database Connection Test Tool
 * CONVERTED: Updated for PostgreSQL and PDO
 */

define('MEDIVAULT_APP', true);

// Load config and session
require_once 'config.php';
require_once 'includes/session.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>MediVault - PostgreSQL Connection Test</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; padding: 20px; background: #f4f4f4; line-height: 1.6; }
        .success { color: #155724; padding: 20px; border: 2px solid #c3e6cb; background: #d4edda; border-radius: 5px; margin: 10px 0; }
        .error { color: #721c24; padding: 20px; border: 2px solid #f5c6cb; background: #f8d7da; border-radius: 5px; margin: 10px 0; }
        .info { color: #0c5460; padding: 20px; border: 2px solid #bee5eb; background: #d1ecf1; border-radius: 5px; margin: 10px 0; }
        pre { background: #fff; padding: 15px; border-radius: 5px; border: 1px solid #ddd; overflow-x: auto; font-size: 0.9rem; }
        h4 { margin-bottom: 10px; border-bottom: 1px solid rgba(0,0,0,0.1); padding-bottom: 5px; }
    </style>
</head>
<body>";

echo "<h2><i class='bi bi-database-check'></i> Testing PostgreSQL Connection</h2>";

// 1. Test Base Connection
$conn = getDBConnection();

if ($conn === false) {
    echo "<div class='error'>";
    echo "<h3>❌ Connection FAILED</h3>";
    echo "<p>Please check your <code>.env</code> file settings and RDS security groups.</p>";
    // Since PDO error info is handled inside getDBConnection's logError, 
    // we provide a general troubleshooting hint here.
    echo "<strong>Check logs:</strong> <code>/logs/error_log.txt</code>";
    echo "</div>";
} else {
    echo "<div class='success'>";
    echo "<h3>✅ Connection SUCCESSFUL!</h3>";
    echo "<strong>Host:</strong> " . DB_HOST . " (Port: " . DB_PORT . ")<br>";
    echo "<strong>Database:</strong> " . DB_NAME . "<br>";
    echo "<strong>SSL Mode:</strong> " . DB_SSLMODE . "<br><br>";
    
    // 2. Test PostgreSQL Specific Version Info
    // Replaced MSSQL @@VERSION and DB_NAME() with PostgreSQL equivalents
    $query = "SELECT version() AS \"Version\", current_database() AS \"CurrentDB\", current_user AS \"CurrentUser\"";
    $result = executeQuery($conn, $query);
    
    if ($result) {
        echo "<h4>Server Environment:</h4>";
        echo "<strong>PostgreSQL Version:</strong><br>";
        echo "<pre>" . htmlspecialchars($result[0]['Version']) . "</pre>";
        echo "<strong>Current Database:</strong> " . htmlspecialchars($result[0]['CurrentDB']) . "<br>";
        echo "<strong>Connected As (DB Role):</strong> " . htmlspecialchars($result[0]['CurrentUser']) . "<br><br>";
    }
    
    // 3. Test if Tables Exist
    // Updated INFORMATION_SCHEMA query for PostgreSQL
    $query = "SELECT COUNT(*) as \"TableCount\" FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE'";
    $result = executeQuery($conn, $query);
    echo "<strong>Schema Check:</strong> Found " . $result[0]['TableCount'] . " tables in the 'public' schema.<br><br>";
    
    // 4. Test Encryption Functionality
    echo "<h4>Encryption Extension Test (pgcrypto):</h4>";
    $testPlaintext = "MediVault-Test-2026";
    $encrypted = encryptData($testPlaintext);
    
    if ($encrypted && $encrypted !== '') {
        $decrypted = decryptData($encrypted);
        if ($decrypted === $testPlaintext) {
            echo "✅ <strong>pgcrypto:</strong> Encryption and Decryption working correctly.<br>";
        } else {
            echo "❌ <strong>pgcrypto:</strong> Decryption failed (Key mismatch or extension error).<br>";
        }
    } else {
        echo "❌ <strong>pgcrypto:</strong> Encryption failed. Ensure <code>pgcrypto</code> extension is enabled in RDS.<br>";
    }

    // 5. Audit Logging Test
    echo "<h4>Audit Log Integration:</h4>";
    $auditTest = insertAuditLog($conn, null, 'TEST', 'connection_test', null, 'Running database connectivity diagnostic');
    if ($auditTest) {
        echo "✅ <strong>Audit Trail:</strong> Test log entry recorded successfully.<br>";
    } else {
        echo "❌ <strong>Audit Trail:</strong> Failed to insert test log. Check <code>log_audit</code> function permissions.<br>";
    }
    
    closeDBConnection($conn);
    echo "</div>";
}

echo "<div class='info'>
    <strong>Note:</strong> Role-based connections in this version utilize the <code>medivault_app</code> 
    user with internal application-level role enforcement. Standard PostgreSQL connection pooling is used.
</div>";

echo "</body></html>";
?>