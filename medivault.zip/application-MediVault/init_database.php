<?php
/**
 * MediVault Database Initializer
 * 
 * This script initializes the MediVault database structure
 * Run this ONCE after deployment to set up all tables and functions
 */

define('MEDIVAULT_APP', true);
require_once 'config.php';

// Security: Only allow initialization if no tables exist
// Remove this check if you want to force re-initialization
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Initialization - MediVault</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 40px; }
        .init-card { background: white; border-radius: 15px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2); max-width: 900px; margin: 0 auto; padding: 30px; }
        .log-output { background: #f8f9fa; border-left: 4px solid #3498db; padding: 15px; font-family: monospace; font-size: 12px; max-height: 400px; overflow-y: auto; }
        .success-msg { color: #27ae60; background: #d5f4e6; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .error-msg { color: #c0392b; background: #fadbd8; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .warning-msg { color: #e67e22; background: #fdebd0; padding: 15px; border-radius: 5px; margin: 15px 0; }
        pre { background: #2c3e50; color: #ecf0f1; padding: 15px; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="init-card">
        <h1 class="text-center mb-4">🏥 MediVault Database Initializer</h1>
        
        <?php
        $conn = getDBConnection();
        
        if (!$conn) {
            echo '<div class="error-msg"><h3>✗ Database Connection Failed</h3>';
            echo '<p>Could not connect to the database. Please check your configuration.</p>';
            echo '<p><strong>Host:</strong> ' . htmlspecialchars(DB_HOST) . '</p>';
            echo '<p><strong>Database:</strong> ' . htmlspecialchars(DB_NAME) . '</p>';
            echo '</div>';
            exit;
        }
        
        echo '<div class="success-msg"><h5>✓ Database Connection Successful</h5></div>';
        
        // Check current state
        try {
            $tableCount = $conn->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public'")->fetchColumn();
            
            echo '<div class="alert alert-info">';
            echo '<h5>Current Database Status:</h5>';
            echo '<p><strong>Tables found:</strong> ' . $tableCount . '</p>';
            
            if ($tableCount > 0) {
                $tables = $conn->query("SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name")->fetchAll();
                echo '<details><summary>View Tables (' . count($tables) . ')</summary><ul class="mt-2">';
                foreach ($tables as $table) {
                    try {
                        $rowCount = $conn->query("SELECT COUNT(*) FROM " . $table['table_name'])->fetchColumn();
                        echo '<li><strong>' . htmlspecialchars($table['table_name']) . '</strong> (' . $rowCount . ' rows)</li>';
                    } catch (Exception $e) {
                        echo '<li><strong>' . htmlspecialchars($table['table_name']) . '</strong> (view or error)</li>';
                    }
                }
                echo '</ul></details>';
            }
            echo '</div>';
            
        } catch (PDOException $e) {
            echo '<div class="error-msg">Error checking tables: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
        
        // Process initialization
        if (isset($_POST['initialize'])) {
            echo '<div class="log-output">';
            echo "<h5>Initialization Log:</h5>\n";
            
            // Find SQL initialization file
            $sqlPaths = [
                __DIR__ . '/postgres-script/db-init.sql',
            ];
            
            $sqlFile = null;
            foreach ($sqlPaths as $path) {
                if (file_exists($path)) {
                    $sqlFile = $path;
                    echo "✓ Found SQL file: " . htmlspecialchars(basename($path)) . "\n";
                    break;
                }
            }
            
            if (!$sqlFile) {
                echo "✗ SQL initialization file not found!\n";
                echo "\nSearched locations:\n";
                foreach ($sqlPaths as $path) {
                    echo "  - " . htmlspecialchars($path) . "\n";
                }
                
                // List actual files in postgres-script folder
                if (is_dir(__DIR__ . '/postgres-script')) {
                    echo "\nFiles in postgres-script folder:\n";
                    $files = scandir(__DIR__ . '/postgres-script');
                    foreach ($files as $file) {
                        if ($file != '.' && $file != '..') {
                            echo "  - " . htmlspecialchars($file) . "\n";
                        }
                    }
                }
                
                echo '</div>';
                echo '<div class="error-msg"><h5>✗ Cannot proceed without SQL file</h5>';
                echo '<p>Please ensure your SQL initialization script is in the postgres-script folder.</p></div>';
            } else {
                // Read SQL file
                $sql = file_get_contents($sqlFile);
                echo "✓ Read " . number_format(strlen($sql)) . " bytes from SQL file\n\n";
                
                // Execute SQL
                try {
                    echo "Executing SQL script...\n";
                    $conn->beginTransaction();
                    
                    // Execute the SQL (PostgreSQL allows multiple statements in exec)
                    $result = $conn->exec($sql);
                    
                    $conn->commit();
                    
                    echo "✓ SQL executed successfully\n\n";
                    
                    // Verify results
                    echo "Verification:\n";
                    $newTableCount = $conn->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public'")->fetchColumn();
                    echo "✓ Tables in database: $newTableCount\n";
                    
                    $tables = $conn->query("SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name")->fetchAll();
                    echo "\nCreated tables:\n";
                    foreach ($tables as $table) {
                        try {
                            $rowCount = $conn->query("SELECT COUNT(*) FROM " . $table['table_name'])->fetchColumn();
                            echo "  - " . $table['table_name'] . " ($rowCount rows)\n";
                        } catch (Exception $e) {
                            echo "  - " . $table['table_name'] . " (view or error)\n";
                        }
                    }
                    
                    echo '</div>';
                    
                    echo '<div class="success-msg">';
                    echo '<h3>✓✓✓ Database Initialized Successfully! ✓✓✓</h3>';
                    echo '<p><strong>' . $newTableCount . '</strong> tables created.</p>';
                    echo '<p>You can now use the MediVault application.</p>';
                    echo '<a href="index.php" class="btn btn-primary mt-3">Go to Login Page →</a>';
                    echo '</div>';
                    
                } catch (PDOException $e) {
                    $conn->rollBack();
                    echo "\n✗ ERROR during execution:\n";
                    echo htmlspecialchars($e->getMessage()) . "\n";
                    echo '</div>';
                    
                    echo '<div class="error-msg">';
                    echo '<h5>✗ Initialization Failed</h5>';
                    echo '<p>Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
                    echo '<p>Please check the SQL file for syntax errors or contact support.</p>';
                    echo '</div>';
                }
            }
            
        } else {
            // Show initialization button
            ?>
            <div class="alert alert-warning">
                <h5>⚠ Important Notes:</h5>
                <ul>
                    <li>This will create all database tables, functions, and initial data</li>
                    <li>If tables already exist, this may cause errors or data loss</li>
                    <li>Make sure you have a backup if the database contains important data</li>
                    <li>This operation cannot be easily undone</li>
                </ul>
            </div>
            
            <form method="POST" action="" onsubmit="return confirm('Are you sure you want to initialize the database? This will create all tables and data.');">
                <div class="text-center">
                    <button type="submit" name="initialize" class="btn btn-primary btn-lg">
                        🚀 Initialize Database Now
                    </button>
                </div>
            </form>
            
            <div class="mt-4">
                <h5>Alternative: Use Adminer</h5>
                <p>You can also manually run SQL scripts using Adminer:</p>
                <ol>
                    <li>Go to <a href="admin.php" target="_blank">Adminer</a></li>
                    <li>Login with your database credentials</li>
                    <li>Click "SQL command"</li>
                    <li>Paste your SQL script and execute</li>
                </ol>
                
                <h5 class="mt-4">Database Connection Details:</h5>
                <pre>Host: <?php echo htmlspecialchars(DB_HOST); ?>
Port: <?php echo htmlspecialchars(DB_PORT); ?>
Database: <?php echo htmlspecialchars(DB_NAME); ?>
Username: <?php echo htmlspecialchars(DB_USER); ?>
SSL Mode: <?php echo htmlspecialchars(DB_SSLMODE); ?></pre>
            </div>
            <?php
        }
        ?>
        
        <div class="mt-4 text-center">
            <a href="index.php" class="btn btn-secondary">← Back to Login</a>
            <a href="db_test.php" class="btn btn-info">Test Connection</a>
            <a href="test_connection.php" class="btn btn-info">Extended Test</a>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>