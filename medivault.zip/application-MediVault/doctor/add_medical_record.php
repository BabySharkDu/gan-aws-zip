<?php
/**
 * Doctor - Add Medical Record
 * Create new medical consultation record
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

// Require Doctor role

requireRole('Doctor');
$pageTitle = 'Add Medical Record';
$errors = array();
$preSelectedPatientId = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : 0;

$conn = getDBConnection();
$patients = array();

if ($conn !== false) {
    $patients = executeQuery($conn, "SELECT patient_id as \"PatientID\", full_name as \"FullName\" FROM patients ORDER BY full_name");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $errors[] = 'Invalid security token.';
    } else {
        $patientId = (int)$_POST['patient_id'];
        $diagnosis = sanitizeInput($_POST['diagnosis'] ?? '');
        $treatment = sanitizeInput($_POST['treatment'] ?? '');
        $prescription = sanitizeInput($_POST['prescription'] ?? '');
        $notes = sanitizeInput($_POST['notes'] ?? '');
        $billAmount = (float)($_POST['bill_amount'] ?? 0.00);
        $status = sanitizeInput($_POST['status'] ?? 'Completed');

        if (empty($diagnosis) || empty($treatment)) { $errors[] = 'Diagnosis and Treatment are required'; }

        if (empty($errors) && $conn !== false) {
            $query = "INSERT INTO medical_records (patient_id, doctor_id, diagnosis, treatment, prescription, notes, bill_amount, status) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?) RETURNING record_id";
            $stmt = $conn->prepare($query);
            $success = $stmt->execute([$patientId, getCurrentUserId(), $diagnosis, $treatment, $prescription, $notes, $billAmount, $status]);
            
            if ($success) {
                $newRecordId = $stmt->fetch()['record_id'];
                insertAuditLog($conn, getCurrentUserId(), 'INSERT', 'medical_records', $newRecordId, "Doctor created medical record");
                showSuccess("Record created successfully!");
                closeDBConnection($conn);
                redirect("doctor/view_patient_details.php?id={$patientId}");
            } else {
                $errors[] = 'Failed to save record.';
            }
        }
    }
}
$csrfToken = generateCSRFToken();
if ($conn !== false) { closeDBConnection($conn); }
include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-file-earmark-plus-fill"></i> Add Medical Record</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item active">Add Medical Record</li>
        </ol>
    </nav>
</div>

<div class="row">
    <div class="col-md-10 mx-auto">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-clipboard-plus"></i> New Medical Consultation
            </div>
            <div class="card-body">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle-fill"></i> <strong>Please correct the following errors:</strong>
                        <ul class="mb-0 mt-2">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="" id="medicalRecordForm">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    
                    <!-- Patient Selection -->
                    <h5 class="border-bottom pb-2 mb-3">
                        <i class="bi bi-person-circle"></i> Patient Information
                    </h5>
                    
                    <div class="mb-3">
                        <label for="patient_id" class="form-label">
                            Select Patient <span class="text-danger">*</span>
                        </label>
                        <select class="form-select" id="patient_id" name="patient_id" required>
                            <option value="">-- Select a Patient --</option>
                            <?php foreach ($patients as $patient): ?>
                                <option value="<?php echo $patient['PatientID']; ?>"
                                    <?php echo ($preSelectedPatientId === $patient['PatientID']) ? 'selected' : ''; ?>>
                                    P-<?php echo str_pad($patient['PatientID'], 5, '0', STR_PAD_LEFT); ?> - 
                                    <?php echo htmlspecialchars($patient['FullName']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Medical Information -->
                    <h5 class="border-bottom pb-2 mb-3 mt-4">
                        <i class="bi bi-heart-pulse"></i> Medical Details
                    </h5>
                    
                    <div class="mb-3">
                        <label for="diagnosis" class="form-label">
                            Diagnosis <span class="text-danger">*</span>
                        </label>
                        <textarea class="form-control" id="diagnosis" name="diagnosis" rows="3" required><?php echo htmlspecialchars($_POST['diagnosis'] ?? ''); ?></textarea>
                        <small class="text-muted">Describe the patient's condition and diagnosis</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="treatment" class="form-label">
                            Treatment <span class="text-danger">*</span>
                        </label>
                        <textarea class="form-control" id="treatment" name="treatment" rows="3" required><?php echo htmlspecialchars($_POST['treatment'] ?? ''); ?></textarea>
                        <small class="text-muted">Recommended treatment plan</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="prescription" class="form-label">
                            Prescription
                        </label>
                        <textarea class="form-control" id="prescription" name="prescription" rows="3"><?php echo htmlspecialchars($_POST['prescription'] ?? ''); ?></textarea>
                        <small class="text-muted">Medication details (name, dosage, frequency)</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="notes" class="form-label">
                            Additional Notes
                        </label>
                        <textarea class="form-control" id="notes" name="notes" rows="2"><?php echo htmlspecialchars($_POST['notes'] ?? ''); ?></textarea>
                        <small class="text-muted">Any additional observations or instructions</small>
                    </div>
                    
                    <!-- Billing and Status -->
                    <h5 class="border-bottom pb-2 mb-3 mt-4">
                        <i class="bi bi-cash-coin"></i> Billing & Status
                    </h5>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="bill_amount" class="form-label">
                                Bill Amount (RM)
                            </label>
                            <input type="number" class="form-control" id="bill_amount" name="bill_amount" 
                                   step="0.01" min="0" value="<?php echo htmlspecialchars($_POST['bill_amount'] ?? '0.00'); ?>">
                        </div>
                        
                        <div class="col-md-6">
                            <label for="status" class="form-label">
                                Status
                            </label>
                            <select class="form-select" id="status" name="status">
                                <option value="Completed" <?php echo (($_POST['status'] ?? 'Completed') === 'Completed') ? 'selected' : ''; ?>>Completed</option>
                                <option value="Pending" <?php echo (($_POST['status'] ?? '') === 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                <option value="Follow-up" <?php echo (($_POST['status'] ?? '') === 'Follow-up') ? 'selected' : ''; ?>>Follow-up Required</option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Submit Buttons -->
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                        <a href="view_patients.php" class="btn btn-secondary">
                            <i class="bi bi-x-circle"></i> Cancel
                        </a>
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-circle-fill"></i> Save Medical Record
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Security Notice -->
        <div class="alert alert-info mt-3">
            <i class="bi bi-shield-check"></i> <strong>Security Notice:</strong> 
            All medical records are logged in the audit trail. Your UserID and timestamp will be recorded with this entry.
        </div>
    </div>
</div>

<script>
// Form validation
document.getElementById('medicalRecordForm').addEventListener('submit', function(e) {
    const patientId = document.getElementById('patient_id').value;
    const diagnosis = document.getElementById('diagnosis').value.trim();
    const treatment = document.getElementById('treatment').value.trim();
    
    if (patientId === '' || patientId === '0') {
        alert('Please select a patient');
        e.preventDefault();
        return false;
    }
    
    if (diagnosis === '') {
        alert('Diagnosis is required');
        e.preventDefault();
        return false;
    }
    
    if (treatment === '') {
        alert('Treatment is required');
        e.preventDefault();
        return false;
    }
});
</script>

<?php
include '../includes/footer.php';
?>