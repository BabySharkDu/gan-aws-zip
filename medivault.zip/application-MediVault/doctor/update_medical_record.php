<?php
/**
 * Doctor - Update Medical Record
 * Edit existing medical consultation record
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

// Require Doctor role
requireRole('Doctor');

$pageTitle = 'Update Medical Record';
$recordId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($recordId === 0) { redirect('/doctor/view_patients.php'); }

$conn = getDBConnection();
$record = null;

if ($conn !== false) {
    $query = "SELECT m.*, p.full_name as \"PatientName\" FROM medical_records m 
               JOIN patients p ON m.patient_id = p.patient_id WHERE m.record_id = ?";
    $res = executeQuery($conn, $query, [$recordId]);
    if ($res) {
        $record = $res[0];
        // Map keys for HTML
        $record['PatientID'] = $record['patient_id'];
        $record['DoctorID'] = $record['doctor_id'];
        $record['Diagnosis'] = $record['diagnosis'];
        $record['Treatment'] = $record['treatment'];
        $record['Prescription'] = $record['prescription'];
        $record['Notes'] = $record['notes'];
        $record['BillAmount'] = $record['bill_amount'];
        $record['Status'] = $record['status'];
        $record['VisitDate'] = $record['visit_date'];

        if ($record['DoctorID'] != getCurrentUserId()) {
            showError('Unauthorized access');
            redirect('/doctor/view_patients.php');
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $record) {
    if (verifyCSRFToken($_POST['csrf_token'])) {
        $query = "UPDATE medical_records SET diagnosis = ?, treatment = ?, prescription = ?, notes = ?, bill_amount = ?, status = ? 
                  WHERE record_id = ? AND doctor_id = ?";
        $params = [
            sanitizeInput($_POST['diagnosis']), sanitizeInput($_POST['treatment']),
            sanitizeInput($_POST['prescription']), sanitizeInput($_POST['notes']),
            (float)$_POST['bill_amount'], sanitizeInput($_POST['status']),
            $recordId, getCurrentUserId()
        ];
        
        if (executeNonQuery($conn, $query, $params)) {
            insertAuditLog($conn, getCurrentUserId(), 'UPDATE', 'medical_records', $recordId, "Doctor updated record");
            showSuccess("Updated successfully!");
            redirect("view_patient_details.php?id={$record['PatientID']}");
        }
    }
}
$csrfToken = generateCSRFToken();
include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-pencil-square"></i> Update Medical Record</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="view_patients.php">Patients</a></li>
            <li class="breadcrumb-item"><a href="view_patient_details.php?id=<?php echo $record['PatientID']; ?>">
                <?php echo htmlspecialchars($patientName); ?>
            </a></li>
            <li class="breadcrumb-item active">Edit Record</li>
        </ol>
    </nav>
</div>

<div class="row">
    <div class="col-md-10 mx-auto">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-clipboard-pulse"></i> Edit Medical Consultation - Record #<?php echo str_pad($recordId, 5, '0', STR_PAD_LEFT); ?>
            </div>
            <div class="card-body">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle-fill"></i> <strong>Please correct the following errors:</strong>
                        <ul class="mb-0 mt-2">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <!-- Patient Info (Read-only) -->
                <div class="alert alert-info">
                    <i class="bi bi-person-circle"></i> <strong>Patient:</strong> <?php echo htmlspecialchars($patientName); ?>
                    <br>
                    <small><strong>Visit Date:</strong> <?php echo date('d M Y, h:i A', strtotime($record['VisitDate'])); ?></small>
                </div>
                
                <form method="POST" action="" id="medicalRecordForm">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    
                    <!-- Medical Information -->
                    <h5 class="border-bottom pb-2 mb-3">
                        <i class="bi bi-heart-pulse"></i> Medical Details
                    </h5>
                    
                    <div class="mb-3">
                        <label for="diagnosis" class="form-label">
                            Diagnosis <span class="text-danger">*</span>
                        </label>
                        <textarea class="form-control" id="diagnosis" name="diagnosis" rows="3" required><?php echo htmlspecialchars($_POST['diagnosis'] ?? $record['Diagnosis']); ?></textarea>
                        <small class="text-muted">Describe the patient's condition and diagnosis</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="treatment" class="form-label">
                            Treatment <span class="text-danger">*</span>
                        </label>
                        <textarea class="form-control" id="treatment" name="treatment" rows="3" required><?php echo htmlspecialchars($_POST['treatment'] ?? $record['Treatment']); ?></textarea>
                        <small class="text-muted">Recommended treatment plan</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="prescription" class="form-label">
                            Prescription
                        </label>
                        <textarea class="form-control" id="prescription" name="prescription" rows="3"><?php echo htmlspecialchars($_POST['prescription'] ?? $record['Prescription']); ?></textarea>
                        <small class="text-muted">Medication details (name, dosage, frequency)</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="notes" class="form-label">
                            Additional Notes
                        </label>
                        <textarea class="form-control" id="notes" name="notes" rows="2"><?php echo htmlspecialchars($_POST['notes'] ?? $record['Notes']); ?></textarea>
                        <small class="text-muted">Any additional observations or instructions</small>
                    </div>
                    
                    <!-- Billing and Status -->
                    <h5 class="border-bottom pb-2 mb-3 mt-4">
                        <i class="bi bi-cash-coin"></i> Billing & Status
                    </h5>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="bill_amount" class="form-label">
                                Bill Amount (RM)
                            </label>
                            <input type="number" class="form-control" id="bill_amount" name="bill_amount" 
                                   step="0.01" min="0" 
                                   value="<?php echo htmlspecialchars($_POST['bill_amount'] ?? $record['BillAmount']); ?>">
                        </div>
                        
                        <div class="col-md-6">
                            <label for="status" class="form-label">
                                Status
                            </label>
                            <select class="form-select" id="status" name="status">
                                <?php
                                $currentStatus = $_POST['status'] ?? $record['Status'];
                                ?>
                                <option value="Completed" <?php echo ($currentStatus === 'Completed') ? 'selected' : ''; ?>>Completed</option>
                                <option value="Pending" <?php echo ($currentStatus === 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                <option value="Follow-up" <?php echo ($currentStatus === 'Follow-up') ? 'selected' : ''; ?>>Follow-up Required</option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Submit Buttons -->
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                        <a href="view_patient_details.php?id=<?php echo $record['PatientID']; ?>" class="btn btn-secondary">
                            <i class="bi bi-x-circle"></i> Cancel
                        </a>
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-circle-fill"></i> Update Medical Record
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Security Warning -->
        <div class="alert alert-warning mt-3">
            <i class="bi bi-exclamation-triangle-fill"></i> <strong>Important:</strong> 
            All changes to medical records are logged in the audit trail. You can only edit records that you created.
        </div>
    </div>
</div>

<script>
// Form validation
document.getElementById('medicalRecordForm').addEventListener('submit', function(e) {
    const diagnosis = document.getElementById('diagnosis').value.trim();
    const treatment = document.getElementById('treatment').value.trim();
    
    if (diagnosis === '') {
        alert('Diagnosis is required');
        e.preventDefault();
        return false;
    }
    
    if (treatment === '') {
        alert('Treatment is required');
        e.preventDefault();
        return false;
    }
});
</script>

<?php
include '../includes/footer.php';
?>