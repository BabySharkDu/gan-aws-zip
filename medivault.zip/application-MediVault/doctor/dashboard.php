<?php
/**
 * Doctor Dashboard
 * Medical overview and patient statistics
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

// Require Doctor role
requireRole('Doctor');
$pageTitle = 'Doctor Dashboard';
$conn = getDBConnection();

// Get statistics
$stats = array('total_patients' => 0, 'total_records' => 0, 'my_records' => 0, 'today_visits' => 0);
$recentRecords = array();

if ($conn !== false) {
    $statsQuery = "SELECT 
        (SELECT COUNT(*) FROM patients) as total_patients,
        (SELECT COUNT(*) FROM medical_records) as total_records,
        (SELECT COUNT(*) FROM medical_records WHERE doctor_id = ?) as my_records,
        (SELECT COUNT(*) FROM medical_records WHERE DATE(visit_date) = CURRENT_DATE) as today_visits";
    
    $res = executeQuery($conn, $statsQuery, [getCurrentUserId()]);
    if ($res) {
        $stats = [
            'total_patients' => $res[0]['total_patients'],
            'total_records'  => $res[0]['total_records'],
            'my_records'     => $res[0]['my_records'],
            'today_visits'   => $res[0]['today_visits']
        ];
    }

    $recentQuery = "SELECT m.record_id as \"RecordID\", p.full_name as \"PatientName\", 
                           m.visit_date as \"VisitDate\", m.diagnosis as \"Diagnosis\", 
                           m.status as \"Status\", m.patient_id as \"PatientID\"
                    FROM medical_records m
                    JOIN patients p ON m.patient_id = p.patient_id
                    WHERE m.doctor_id = ?
                    ORDER BY m.visit_date DESC LIMIT 10";
    $recentRecords = executeQuery($conn, $recentQuery, [getCurrentUserId()]);
    
    closeDBConnection($conn);
}
include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-heart-pulse-fill"></i> Doctor Dashboard</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </nav>
</div>

<!-- Welcome Message -->
<div class="alert alert-info alert-dismissible fade show" role="alert">
    <i class="bi bi-info-circle-fill"></i>
    <strong>Welcome back, Dr. <?php echo htmlspecialchars(getCurrentUsername()); ?>!</strong> 
    You have <?php echo $stats['today_visits']; ?> patient visit(s) recorded today.
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>

<!-- Statistics Cards -->
<div class="row">
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">Total Patients</h6>
                        <h2 class="mb-0"><?php echo $stats['total_patients']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-people-fill" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <a href="view_patients.php" class="text-white text-decoration-none">
                    View patients <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-success">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">My Records</h6>
                        <h2 class="mb-0"><?php echo $stats['my_records']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-file-earmark-medical-fill" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <span class="text-white">Records created by you</span>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-info">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">Today's Visits</h6>
                        <h2 class="mb-0"><?php echo $stats['today_visits']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-calendar-check-fill" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <span class="text-white"><?php echo date('d M Y'); ?></span>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title text-uppercase mb-0">All Records</h6>
                        <h2 class="mb-0"><?php echo $stats['total_records']; ?></h2>
                    </div>
                    <div>
                        <i class="bi bi-hospital-fill" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-dark bg-opacity-25">
                <span class="text-white">System-wide</span>
            </div>
        </div>
    </div>
</div>

<!-- Recent Medical Records -->
<div class="card mb-4">
    <div class="card-header">
        <i class="bi bi-clock-history"></i> Recent Patient Consultations
    </div>
    <div class="card-body">
        <?php if (!empty($recentRecords)): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Record ID</th>
                            <th>Patient Name</th>
                            <th>Visit Date</th>
                            <th>Diagnosis</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentRecords as $record): ?>
                            <tr>
                                <td>
                                    <strong class="text-primary">
                                        R-<?php echo str_pad($record['RecordID'], 5, '0', STR_PAD_LEFT); ?>
                                    </strong>
                                </td>
                                <td>
                                    <i class="bi bi-person-circle"></i> 
                                    <?php echo htmlspecialchars($record['PatientName']); ?>
                                </td>
                                <td>
                                    <small><?php echo date('d M Y, h:i A', strtotime($record['VisitDate'])); ?></small>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars(substr($record['Diagnosis'], 0, 50)); ?>
                                    <?php if (strlen($record['Diagnosis']) > 50) echo '...'; ?>
                                </td>
                                <td>
                                    <?php
                                    $badgeClass = 'bg-secondary';
                                    if ($record['Status'] === 'Completed') $badgeClass = 'bg-success';
                                    if ($record['Status'] === 'Pending') $badgeClass = 'bg-warning';
                                    ?>
                                    <span class="badge <?php echo $badgeClass; ?>">
                                        <?php echo htmlspecialchars($record['Status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="view_patient_details.php?id=<?php echo $record['PatientID']; ?>" 
                                       class="btn btn-sm btn-info">
                                        <i class="bi bi-eye-fill"></i> View
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted">No recent consultations.</p>
        <?php endif; ?>
    </div>
</div>

<!-- Quick Actions -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-lightning-fill"></i> Quick Actions
    </div>
    <div class="card-body">
        <div class="d-grid gap-2 d-md-flex">
            <a href="view_patients.php" class="btn btn-primary btn-lg">
                <i class="bi bi-person-lines-fill"></i> View All Patients
            </a>
            <a href="add_medical_record.php" class="btn btn-success btn-lg">
                <i class="bi bi-file-earmark-plus-fill"></i> Add Medical Record
            </a>
            <a href="view_patients.php?search=" class="btn btn-info btn-lg text-white">
                <i class="bi bi-search"></i> Search Patients
            </a>
        </div>
    </div>
</div>

<?php
include '../includes/footer.php';
?>