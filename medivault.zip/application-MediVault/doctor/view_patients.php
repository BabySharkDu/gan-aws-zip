<?php
/**
 * Doctor - View Patients
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

requireRole('Doctor');
$pageTitle = 'View Patients';

// Get search parameter
$searchTerm = sanitizeInput($_GET['search'] ?? '');

// Connect to database
$conn = getDBConnection();
$patients = array();

if ($conn !== false) {
    if (!empty($searchTerm)) {
        // Search by patient name (case-insensitive)
        $query = "SELECT p.patient_id, p.full_name, p.date_of_birth, p.gender, p.blood_type,
                         p.ic_number_encrypted, p.phone_number_encrypted, p.registered_date,
                         u.username as registered_by_name
                  FROM patients p
                  LEFT JOIN users u ON p.registered_by = u.user_id
                  WHERE p.full_name ILIKE ?
                  ORDER BY p.full_name";
        $patients = executeQuery($conn, $query, ["%$searchTerm%"]);
    } else {
        // Get all patients
        $query = "SELECT p.patient_id, p.full_name, p.date_of_birth, p.gender, p.blood_type,
                         p.ic_number_encrypted, p.phone_number_encrypted, p.registered_date,
                         u.username as registered_by_name
                  FROM patients p
                  LEFT JOIN users u ON p.registered_by = u.user_id
                  ORDER BY p.full_name";
        $patients = executeQuery($conn, $query);
    }

    // Decrypt sensitive fields in PHP
    foreach ($patients as &$patient) {
        $patient['ic_number'] = decryptData($patient['ic_number_encrypted']);
        $patient['phone_number'] = decryptData($patient['phone_number_encrypted']);
    }
    unset($patient); // Break reference

    insertAuditLog($conn, getCurrentUserId(), 'SELECT', 'patients', null,
                "Doctor viewed patient list" . (!empty($searchTerm) ? " (searched: {$searchTerm})" : ""));
    
    closeDBConnection($conn);
}

include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-person-lines-fill"></i> Patient Records</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item active">Patients</li>
        </ol>
    </nav>
</div>

<!-- Search and Actions -->
<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="" class="row g-3">
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" class="form-control" name="search" 
                           placeholder="Search by name or IC number..." 
                           value="<?php echo htmlspecialchars($searchTerm); ?>">
                    <button type="submit" class="btn btn-primary">Search</button>
                    <?php if (!empty($searchTerm)): ?>
                        <a href="view_patients.php" class="btn btn-secondary">Clear</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6 text-end">
                <span class="badge bg-info" style="font-size: 1rem; padding: 10px;">
                    Total Patients: <?php echo count($patients); ?>
                </span>
            </div>
        </form>
    </div>
</div>

<!-- Patients Table -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-table"></i> Patient List
        <?php if (!empty($searchTerm)): ?>
            <span class="badge bg-warning text-dark">Filtered Results</span>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php if (!empty($patients)): ?>
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="table-primary">
                        <tr>
                            <th>Patient ID</th>
                            <th>Full Name</th>
                            <th>IC Number <i class="bi bi-shield-lock-fill text-success"></i></th>
                            <th>Gender</th>
                            <th>Blood Type</th>
                            <th>Phone <i class="bi bi-shield-lock-fill text-success"></i></th>
                            <th>Registered Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($patients as $patient): ?>
                            <tr>
                                <td>
                                    <strong class="text-primary">P-<?php echo str_pad($patient['patient_id'], 5, '0', STR_PAD_LEFT); ?></strong>
                                </td>
                                <td>
                                    <i class="bi bi-person-circle"></i> 
                                    <?php echo htmlspecialchars($patient['full_name']); ?>
                                </td>
                                <td>
                                    <code><?php echo htmlspecialchars($patient['ic_number'] ?? 'N/A'); ?></code>
                                </td>
                                <td>
                                    <?php
                                    $genderIcon = '';
                                    $genderText = '';
                                    switch($patient['gender']) {
                                        case 'M':
                                            $genderIcon = 'bi-gender-male text-primary';
                                            $genderText = 'Male';
                                            break;
                                        case 'F':
                                            $genderIcon = 'bi-gender-female text-danger';
                                            $genderText = 'Female';
                                            break;
                                        default:
                                            $genderIcon = 'bi-gender-ambiguous text-secondary';
                                            $genderText = 'Other';
                                    }
                                    ?>
                                    <i class="bi <?php echo $genderIcon; ?>"></i> <?php echo $genderText; ?>
                                </td>
                                <td>
                                    <?php if (!empty($patient['blood_type'])): ?>
                                        <span class="badge bg-danger">
                                            <?php echo htmlspecialchars($patient['blood_type']); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted">Unknown</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <i class="bi bi-telephone-fill"></i> 
                                    <?php echo htmlspecialchars($patient['phone_number'] ?? 'N/A'); ?>
                                </td>
                                <td>
                                    <small><?php echo date('d M Y', strtotime($patient['registered_date'])); ?></small>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <a href="view_patient_details.php?id=<?php echo $patient['patient_id']; ?>" 
                                           class="btn btn-info" title="View Details">
                                            <i class="bi bi-eye-fill"></i>
                                        </a>
                                        <a href="add_medical_record.php?patient_id=<?php echo $patient['patient_id']; ?>" 
                                           class="btn btn-success" title="Add Medical Record">
                                            <i class="bi bi-file-earmark-plus-fill"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination Info (Simple) -->
            <div class="mt-3">
                <p class="text-muted">
                    Showing <?php echo count($patients); ?> patient(s)
                </p>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                <i class="bi bi-exclamation-triangle-fill"></i> 
                <?php if (!empty($searchTerm)): ?>
                    No patients found matching "<?php echo htmlspecialchars($searchTerm); ?>"
                <?php else: ?>
                    No patients registered yet.
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Security Notice -->
<div class="alert alert-info mt-3">
    <i class="bi bi-info-circle-fill"></i> <strong>Data Security Notice:</strong><br>
    <ul class="mb-0 mt-2">
        <li><i class="bi bi-shield-lock-fill text-success"></i> <strong>Encrypted fields</strong> (IC Number, Phone Number) are decrypted for authorized doctors</li>
        <li><i class="bi bi-journal-text"></i> All patient data access is logged in the audit trail</li>
        <li><i class="bi bi-eye-slash-fill"></i> Only authorized medical staff can view sensitive patient information</li>
    </ul>
</div>

<script>
// Highlight search terms in results
<?php if (!empty($searchTerm)): ?>
document.addEventListener('DOMContentLoaded', function() {
    const searchTerm = <?php echo json_encode($searchTerm); ?>;
    const tbody = document.querySelector('tbody');
    
    if (tbody) {
        const regex = new RegExp('(' + searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi');
        tbody.innerHTML = tbody.innerHTML.replace(regex, '<mark>$1</mark>');
    }
});
<?php endif; ?>
</script>

<?php
include '../includes/footer.php';
?>