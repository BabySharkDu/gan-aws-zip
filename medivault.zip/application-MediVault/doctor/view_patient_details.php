<?php
/**
 * Doctor - View Patient Detail
 * Full patient information with medical history
 */

define('MEDIVAULT_APP', true);
require_once '../config.php';
require_once '../includes/session.php';

// Require Doctor role
requireRole('Doctor');

$pageTitle = 'Patient Details';

// Get patient ID from URL
$patientId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($patientId === 0) {
    showError('Invalid patient ID');
    redirect('/doctor/view_patients.php');
}

// Connect to database
$conn = getDBConnection();
$patient = null;
$medicalRecords = array();

if ($conn !== false) {
    // 1. Get Patient Details
    $pQuery = "SELECT p.*, u.username as \"RegisteredBy\" FROM patients p 
               LEFT JOIN users u ON p.registered_by = u.user_id WHERE p.patient_id = ?";
    $pRes = executeQuery($conn, $pQuery, [$patientId]);

    if ($pRes) {
        $patient = $pRes[0];
        // Decrypt sensitive fields
        $patient['ICNumber'] = decryptData($patient['ic_number_encrypted']);
        $patient['PhoneNumber'] = decryptData($patient['phone_number_encrypted']);
        // Alias for HTML consistency
        $patient['FullName'] = $patient['full_name'];
        $patient['PatientID'] = $patient['patient_id'];
        $patient['DateOfBirth'] = $patient['date_of_birth'];
        $patient['Gender'] = $patient['gender'];
        $patient['BloodType'] = $patient['blood_type'];
        $patient['EmergencyContact'] = $patient['emergency_contact'];
        $patient['RegisteredDate'] = $patient['registered_date'];

        // 2. Get Medical History
        $mQuery = "SELECT m.record_id as \"RecordID\", m.visit_date as \"VisitDate\", 
                          m.diagnosis as \"Diagnosis\", m.treatment as \"Treatment\", 
                          m.prescription as \"Prescription\", m.notes as \"Notes\", 
                          m.bill_amount as \"BillAmount\", m.status as \"Status\", 
                          m.doctor_id as \"DoctorID\", u.username as \"DoctorName\"
                   FROM medical_records m
                   JOIN users u ON m.doctor_id = u.user_id
                   WHERE m.patient_id = ? ORDER BY m.visit_date DESC";
        $medicalRecords = executeQuery($conn, $mQuery, [$patientId]);
    }

    insertAuditLog($conn, getCurrentUserId(), 'SELECT', 'patients', $patientId, "Doctor viewed patient details: " . ($patient['FullName'] ?? 'ID '.$patientId));
    closeDBConnection($conn);
}
include '../includes/header.php';
?>

<div class="page-header">
    <h1><i class="bi bi-person-badge-fill"></i> Patient Details</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="view_patients.php">Patients</a></li>
            <li class="breadcrumb-item active"><?php echo htmlspecialchars($patient['FullName']); ?></li>
        </ol>
    </nav>
</div>

<!-- Patient Information Card -->
<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <i class="bi bi-person-circle"></i> Patient Information
            </div>
            <div class="card-body">
                <div class="text-center mb-3">
                    <i class="bi bi-person-circle" style="font-size: 5rem; color: var(--primary-color);"></i>
                    <h4 class="mt-2"><?php echo htmlspecialchars($patient['FullName']); ?></h4>
                    <p class="text-muted">
                        Patient ID: <strong>P-<?php echo str_pad($patient['PatientID'], 5, '0', STR_PAD_LEFT); ?></strong>
                    </p>
                </div>
                
                <table class="table table-sm">
                    <tr>
                        <th width="40%">IC Number:</th>
                        <td><code><?php echo htmlspecialchars($patient['ICNumber'] ?? 'N/A'); ?></code></td>
                    </tr>
                    <tr>
                        <th>Date of Birth:</th>
                        <td>
                            <?php 
                            if ($patient['DateOfBirth']) {
                                $dob = new DateTime($patient['DateOfBirth']);
                                $age = $dob->diff(new DateTime())->y;
                                echo $dob->format('d M Y') . " <br><small class='text-muted'>Age: {$age} years</small>";
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Gender:</th>
                        <td>
                            <?php
                            $icon = $patient['Gender'] === 'M' ? 'bi-gender-male text-primary' : 'bi-gender-female text-danger';
                            $text = $patient['Gender'] === 'M' ? 'Male' : 'Female';
                            ?>
                            <i class="bi <?php echo $icon; ?>"></i> <?php echo $text; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Blood Type:</th>
                        <td>
                            <?php if (!empty($patient['BloodType'])): ?>
                                <span class="badge bg-danger"><?php echo htmlspecialchars($patient['BloodType']); ?></span>
                            <?php else: ?>
                                <span class="text-muted">Unknown</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Phone:</th>
                        <td><i class="bi bi-telephone-fill"></i> <?php echo htmlspecialchars($patient['PhoneNumber'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>Address:</th>
                        <td><small><?php echo htmlspecialchars($patient['Address'] ?? 'N/A'); ?></small></td>
                    </tr>
                    <tr>
                        <th>Emergency:</th>
                        <td><small><?php echo htmlspecialchars($patient['EmergencyContact'] ?? 'N/A'); ?></small></td>
                    </tr>
                    <tr>
                        <th>Registered:</th>
                        <td>
                            <small><?php echo date('d M Y', strtotime($patient['RegisteredDate'])); ?></small>
                            <br>
                            <small class="text-muted">By: <?php echo htmlspecialchars($patient['RegisteredBy']); ?></small>
                        </td>
                    </tr>
                </table>
                
                <div class="d-grid gap-2 mt-3">
                    <a href="add_medical_record.php?patient_id=<?php echo $patient['PatientID']; ?>" 
                       class="btn btn-success">
                        <i class="bi bi-file-earmark-plus-fill"></i> Add Medical Record
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-8 mb-4">
        <!-- Medical History -->
        <div class="card">
            <div class="card-header bg-success text-white">
                <i class="bi bi-clipboard2-pulse-fill"></i> Medical History
                <span class="badge bg-light text-dark float-end"><?php echo count($medicalRecords); ?> records</span>
            </div>
            <div class="card-body">
                <?php if (!empty($medicalRecords)): ?>
                    <?php foreach ($medicalRecords as $record): ?>
                        <div class="card mb-3">
                            <div class="card-header">
                                <div class="row">
                                    <div class="col-md-8">
                                        <strong>Record #<?php echo str_pad($record['RecordID'], 5, '0', STR_PAD_LEFT); ?></strong>
                                        <small class="text-muted">
                                            - <?php echo date('d M Y, h:i A', strtotime($record['VisitDate'])); ?>
                                        </small>
                                    </div>
                                    <div class="col-md-4 text-end">
                                        <?php if ($record['DoctorID'] == getCurrentUserId()): ?>
                                            <a href="update_medical_record.php?id=<?php echo $record['RecordID']; ?>" 
                                            class="btn btn-sm btn-primary me-2" title="Edit Record">
                                                <i class="bi bi-pencil-square"></i> Edit
                                            </a>
                                        <?php endif; ?>

                                        <?php
                                        $badgeClass = 'bg-secondary';
                                        if ($record['Status'] === 'Completed') $badgeClass = 'bg-success';
                                        if ($record['Status'] === 'Pending') $badgeClass = 'bg-warning';
                                        ?>
                                        <span class="badge <?php echo $badgeClass; ?>">
                                            <?php echo htmlspecialchars($record['Status']); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p><strong><i class="bi bi-heart-pulse"></i> Diagnosis:</strong></p>
                                        <p class="ms-3"><?php echo nl2br(htmlspecialchars($record['Diagnosis'])); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong><i class="bi bi-bandaid-fill"></i> Treatment:</strong></p>
                                        <p class="ms-3"><?php echo nl2br(htmlspecialchars($record['Treatment'])); ?></p>
                                    </div>
                                </div>
                                
                                <?php if (!empty($record['Prescription'])): ?>
                                    <p><strong><i class="bi bi-capsule"></i> Prescription:</strong></p>
                                    <p class="ms-3"><?php echo nl2br(htmlspecialchars($record['Prescription'])); ?></p>
                                <?php endif; ?>
                                
                                <?php if (!empty($record['Notes'])): ?>
                                    <p><strong><i class="bi bi-journal-text"></i> Notes:</strong></p>
                                    <p class="ms-3 text-muted"><em><?php echo nl2br(htmlspecialchars($record['Notes'])); ?></em></p>
                                <?php endif; ?>
                                
                                <hr>
                                <div class="d-flex justify-content-between">
                                    <small class="text-muted">
                                        <i class="bi bi-person-badge"></i> Dr. <?php echo htmlspecialchars($record['DoctorName']); ?>
                                    </small>
                                    <small>
                                        <strong>Bill: RM <?php echo number_format($record['BillAmount'], 2); ?></strong>
                                    </small>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle-fill"></i> No medical records yet for this patient.
                        <a href="add_medical_record.php?patient_id=<?php echo $patient['PatientID']; ?>" 
                           class="alert-link">Add the first record</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Back Button -->
<div class="mb-3">
    <a href="view_patients.php" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Back to Patient List
    </a>
</div>

<?php
include '../includes/footer.php';
?>