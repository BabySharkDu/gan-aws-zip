<?php
/**
 * MediVault Session Management & Security
 * FIXED: Proper session initialization and path handling
 */

// ================================================================
// Session Configuration
// ================================================================

// 1. Configure session path BEFORE starting session
$sessionPath = __DIR__ . '/../sessions';

// 2. Create sessions directory if it doesn't exist
if (!file_exists($sessionPath)) {
    mkdir($sessionPath, 0755, true);
}

// 3. Set session save path
if (file_exists($sessionPath) && is_writable($sessionPath)) {
    session_save_path($sessionPath);
}

// 4. Configure session security settings BEFORE starting
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_lifetime', 0);
ini_set('session.gc_maxlifetime', 86400); // 24 hours

// 5. Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 6. Regenerate session ID periodically to prevent session fixation
if (!isset($_SESSION['created'])) {
    $_SESSION['created'] = time();
} elseif (time() - $_SESSION['created'] > 1800) { // 30 minutes
    session_regenerate_id(true);
    $_SESSION['created'] = time();
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && 
           isset($_SESSION['username']) && 
           isset($_SESSION['role']);
}

/**
 * Require login - redirect to login page if not authenticated
 */
function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        
        // Log the access attempt
        if (defined('BASE_URL')) {
            header("Location: " . BASE_URL . "index.php?error=" . urlencode("Please login first"));
        } else {
            header("Location: ../index.php?error=" . urlencode("Please login first"));
        }
        exit();
    }
    
    // Check session timeout
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
        session_unset();
        session_destroy();
        
        if (defined('BASE_URL')) {
            header("Location: " . BASE_URL . "index.php?error=" . urlencode("Session expired"));
        } else {
            header("Location: ../index.php?error=" . urlencode("Session expired"));
        }
        exit();
    }
    
    $_SESSION['last_activity'] = time();
}

/**
 * Check if user has specific role
 */
function hasRole($requiredRole) {
    return isset($_SESSION['role']) && $_SESSION['role'] === $requiredRole;
}

/**
 * Require specific role - redirect if user doesn't have permission
 */
function requireRole($requiredRole) {
    requireLogin();
    
    if (!hasRole($requiredRole)) {
        if (defined('BASE_URL')) {
            header("Location: " . BASE_URL . "unauthorized.php");
        } else {
            header("Location: ../unauthorized.php");
        }
        exit();
    }
}

/**
 * Get current user ID
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get current username
 */
function getCurrentUsername() {
    return $_SESSION['username'] ?? null;
}

/**
 * Get current user role
 */
function getCurrentRole() {
    return $_SESSION['role'] ?? null;
}

/**
 * Get current user email
 */
function getCurrentEmail() {
    return $_SESSION['email'] ?? null;
}

/**
 * Set user session after successful login
 */
function setUserSession($userId, $username, $role, $email) {
    // Regenerate session ID for security
    session_regenerate_id(true);
    
    // Set session variables
    $_SESSION['user_id'] = $userId;
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $role;
    $_SESSION['email'] = $email;
    $_SESSION['login_time'] = time();
    $_SESSION['last_activity'] = time();
    $_SESSION['ip_address'] = $_SERVER['REMOTE_ADDR'];
    $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
    
    // Debug: Log successful session creation
    if (defined('APP_DEBUG') && APP_DEBUG) {
        error_log("Session created for user: $username (Role: $role, ID: $userId)");
    }
}

/**
 * Destroy user session (logout)
 */
function destroyUserSession() {
    $_SESSION = array();
    
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    session_destroy();
}

/**
 * Get role-specific dashboard URL
 */
function getDashboardUrl($role = null) {
    $role = $role ?? getCurrentRole();
    
    switch ($role) {
        case 'Administrator':
            return 'admin/dashboard.php';
        case 'Doctor':
            return 'doctor/dashboard.php';
        case 'Receptionist':
            return 'receptionist/dashboard.php';
        case 'Auditor':
            return 'auditor/dashboard.php';
        default:
            return 'index.php';
    }
}

/**
 * Log user activity
 */
function logUserActivity($conn, $action, $details = null) {
    $userId = getCurrentUserId();
    
    if ($userId && function_exists('insertAuditLog')) {
        insertAuditLog($conn, $userId, $action, 'User Activity', null, $details);
    }
}
?>